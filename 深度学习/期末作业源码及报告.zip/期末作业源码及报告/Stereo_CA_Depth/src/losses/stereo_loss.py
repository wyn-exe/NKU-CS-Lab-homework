"""Loss functions for stereo disparity estimation."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class DisparitySmoothL1Loss(nn.Module):
    """Smooth L1 loss computed only on valid disparity pixels.

    Args:
        beta: Transition point between L1 and L2 behavior in Smooth L1.
    """

    def __init__(self, beta: float = 1.0) -> None:
        super().__init__()
        self.beta = beta

    def forward(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        """Compute masked Smooth L1 loss.

        Args:
            pred: Predicted disparity (B, 1, H, W).
            target: Ground truth disparity (B, 1, H, W).
            mask: Valid pixel mask (B, 1, H, W), True = valid.

        Returns:
            Scalar loss averaged over valid pixels.
        """
        # Ensure same resolution (pred may be at different scale)
        if pred.shape[-2:] != target.shape[-2:]:
            pred = F.interpolate(
                pred, size=target.shape[-2:], mode="bilinear", align_corners=False
            )
            # If pred was at lower resolution, scale it up
            scale_h = target.shape[-2] / pred.shape[-2] if hasattr(pred, "_scale") else 1.0
            # Actually we just interpolate and assume pred values are already correct

        diff = pred - target
        loss = F.smooth_l1_loss(diff, torch.zeros_like(diff), beta=self.beta, reduction="none")

        # Apply mask
        masked_loss = loss * mask.float()

        # Average over valid pixels
        num_valid = mask.float().sum() + 1e-8
        return masked_loss.sum() / num_valid


class EdgeAwareSmoothnessLoss(nn.Module):
    """Edge-aware disparity smoothness loss (optional).

    Encourages disparity to be smooth except at image edges.
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(
        self, disp: torch.Tensor, img: torch.Tensor
    ) -> torch.Tensor:
        """Compute edge-aware smoothness.

        Args:
            disp: Disparity map (B, 1, H, W).
            img: Reference image (B, 3, H, W).

        Returns:
            Scalar smoothness loss.
        """
        # Gradient of disparity
        grad_disp_x = torch.abs(disp[:, :, :, :-1] - disp[:, :, :, 1:])
        grad_disp_y = torch.abs(disp[:, :, :-1, :] - disp[:, :, 1:, :])

        # Gradient of image (edge-aware weight)
        grad_img_x = torch.abs(img[:, :, :, :-1] - img[:, :, :, 1:]).mean(dim=1, keepdim=True)
        grad_img_y = torch.abs(img[:, :, :-1, :] - img[:, :, 1:, :]).mean(dim=1, keepdim=True)

        # Weighted smoothness: penalize disparity gradients less at image edges
        weight_x = torch.exp(-grad_img_x)
        weight_y = torch.exp(-grad_img_y)

        loss_x = (grad_disp_x * weight_x).mean()
        loss_y = (grad_disp_y * weight_y).mean()

        return loss_x + loss_y
