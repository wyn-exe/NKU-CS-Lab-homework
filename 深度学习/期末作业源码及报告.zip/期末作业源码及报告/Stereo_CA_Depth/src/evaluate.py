"""Evaluate a stereo disparity model checkpoint.

Usage:
    python src/evaluate.py --config configs/baseline.yaml --checkpoint experiments/baseline/checkpoint_best.pt
    python src/evaluate.py --config configs/ca_full.yaml --checkpoint experiments/ca_full/checkpoint_best.pt --output results/ca_full_metrics.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Optional

import torch
from torch.utils.data import DataLoader

from config_utils import build_model_from_config, load_yaml_config
from datasets import StereoDataset
from losses import DisparitySmoothL1Loss
from metrics import compute_all_metrics, count_parameters


def format_metrics(metrics: Dict[str, float]) -> str:
    parts = []
    for key, value in metrics.items():
        if key == "d1":
            parts.append(f"D1={value:.4f}")
        elif key == "num_params":
            parts.append(f"Params={int(value):,}")
        else:
            parts.append(f"{key.upper()}={value:.4f}")
    return " | ".join(parts)


def load_checkpoint(model: torch.nn.Module, checkpoint_path: Optional[Path], device: torch.device) -> None:
    """Load a checkpoint if one is supplied."""
    if checkpoint_path is None:
        print("Warning: no checkpoint supplied; evaluating randomly initialized weights.")
        return
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=device)
    if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
        state_dict = checkpoint["model_state_dict"]
    else:
        state_dict = checkpoint
    model.load_state_dict(state_dict)


@torch.no_grad()
def evaluate(config_path: Path, checkpoint_path: Optional[Path], split: str) -> Dict[str, float]:
    config = load_yaml_config(config_path)
    data_cfg = config["data"]
    train_cfg = config.get("training", {})
    eval_cfg = config.get("evaluation", {})

    split_name = data_cfg.get(f"{split}_split", split)
    if split == "val":
        split_name = data_cfg.get("val_split", "val")
    data_root = Path(data_cfg["root"]) / split_name

    dataset = StereoDataset(
        data_root=str(data_root),
        split=split,
        left_dir=data_cfg.get("left_dir", "left"),
        right_dir=data_cfg.get("right_dir", "right"),
        disp_dir=data_cfg.get("disp_dir", "disp"),
        crop_size=None,
        max_disp=config["model"]["max_disp"],
    )
    loader = DataLoader(
        dataset,
        batch_size=eval_cfg.get("batch_size", train_cfg.get("batch_size", 1)),
        shuffle=False,
        num_workers=eval_cfg.get("num_workers", train_cfg.get("num_workers", 0)),
        pin_memory=torch.cuda.is_available(),
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model_from_config(config).to(device)
    load_checkpoint(model, checkpoint_path, device)
    model.eval()

    criterion = DisparitySmoothL1Loss(beta=1.0)
    totals: Dict[str, float] = {"epe": 0.0, "d1": 0.0, "mae": 0.0, "rmse": 0.0, "loss": 0.0}
    num_batches = 0

    for batch in loader:
        left = batch["left"].to(device)
        right = batch["right"].to(device)
        disp_gt = batch["disp"].to(device)
        mask = batch["mask"].to(device)

        pred_disp = model(left, right)["disp"]
        loss = criterion(pred_disp, disp_gt, mask)
        batch_metrics = compute_all_metrics(pred_disp, disp_gt, mask)
        batch_metrics["loss"] = loss.item()

        for key in totals:
            totals[key] += batch_metrics[key]
        num_batches += 1

    metrics = {key: value / max(num_batches, 1) for key, value in totals.items()}
    metrics["num_params"] = float(count_parameters(model))
    metrics["num_samples"] = float(len(dataset))
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate stereo disparity model")
    parser.add_argument("--config", type=Path, required=True, help="Path to YAML config")
    parser.add_argument("--checkpoint", type=Path, default=None, help="Path to checkpoint_best.pt")
    parser.add_argument("--split", type=str, default="val", help="Dataset split name, usually val or test_vis")
    parser.add_argument("--output", type=Path, default=None, help="Optional JSON output path")
    args = parser.parse_args()

    metrics = evaluate(args.config, args.checkpoint, args.split)
    print(format_metrics(metrics))

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2, ensure_ascii=False)
        print(f"Saved metrics to: {args.output}")


if __name__ == "__main__":
    main()
