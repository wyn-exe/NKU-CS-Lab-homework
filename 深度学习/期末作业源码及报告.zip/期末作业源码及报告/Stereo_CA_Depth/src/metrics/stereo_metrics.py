"""Evaluation metrics for stereo disparity estimation.

Implements standard stereo matching metrics:
  - EPE (End-Point Error)
  - D1-error (bad pixel rate)
  - MAE (Mean Absolute Error)
  - RMSE (Root Mean Square Error)
"""

from __future__ import annotations

from typing import Dict

import torch


def compute_epe(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> float:
    """End-Point Error: mean absolute disparity error on valid pixels.

    Args:
        pred: (B, 1, H, W) or (1, H, W) predicted disparity.
        target: Same shape, ground truth disparity.
        mask: Same shape, bool tensor (True = valid).

    Returns:
        EPE in pixels.
    """
    diff = (pred - target).abs()
    valid = mask.float()
    num_valid = valid.sum() + 1e-8
    return (diff * valid).sum().item() / num_valid.item()


def compute_d1_error(
    pred: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    threshold: float = 3.0,
) -> float:
    """D1-error (bad pixel rate).

    A pixel is considered bad if:
        |pred - target| > threshold  AND  |pred - target| / |target| > 0.05

    Args:
        pred: Predicted disparity.
        target: Ground truth disparity.
        mask: Valid pixel mask.
        threshold: Absolute error threshold in pixels.

    Returns:
        D1-error rate (0.0 to 1.0).
    """
    diff = (pred - target).abs().squeeze(1)
    target_sq = target.abs().squeeze(1)
    mask_sq = mask.squeeze(1)
    valid = mask_sq.float()
    num_valid = valid.sum() + 1e-8

    bad = (diff > threshold) & (diff / (target_sq + 1e-8) > 0.05)
    bad_count = (bad.float() * valid).sum()
    return bad_count.item() / num_valid.item()


def compute_mae(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> float:
    """Mean Absolute Error (same as EPE for single-pixel comparison)."""
    return compute_epe(pred, target, mask)


def compute_rmse(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> float:
    """Root Mean Square Error on valid pixels.

    Args:
        pred: Predicted disparity.
        target: Ground truth disparity.
        mask: Valid pixel mask.

    Returns:
        RMSE in pixels.
    """
    diff = (pred - target) ** 2
    valid = mask.float()
    num_valid = valid.sum() + 1e-8
    mse = (diff * valid).sum().item() / num_valid.item()
    return mse ** 0.5


def compute_all_metrics(
    pred: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
) -> Dict[str, float]:
    """Compute all standard stereo metrics.

    Args:
        pred: (B, 1, H, W) predicted disparity.
        target: (B, 1, H, W) ground truth disparity.
        mask: (B, 1, H, W) valid pixel mask.

    Returns:
        dict with keys: epe, d1, mae, rmse.
    """
    return {
        "epe": compute_epe(pred, target, mask),
        "d1": compute_d1_error(pred, target, mask),
        "mae": compute_mae(pred, target, mask),
        "rmse": compute_rmse(pred, target, mask),
    }


def count_parameters(model: torch.nn.Module) -> int:
    """Count trainable parameters."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
