"""Training entry point for stereo disparity estimation.

Usage:
    python src/train.py --config configs/baseline.yaml
    python src/train.py --config configs/ca_full.yaml
"""

from __future__ import annotations

import os
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

import argparse
import json
import random
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from config_utils import build_model_from_config, load_yaml_config
from datasets import StereoDataset, build_train_transform
from losses import DisparitySmoothL1Loss
from metrics import compute_all_metrics, count_parameters
from models import StereoBaseline


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def format_metrics(metrics: Dict[str, float]) -> str:
    """Format metrics dict into a single-line string."""
    parts = []
    for k, v in metrics.items():
        if k in ("epe", "mae", "rmse"):
            parts.append(f"{k.upper()}={v:.3f}")
        elif k == "d1":
            parts.append(f"D1={v:.4f}")
        elif k == "loss":
            parts.append(f"Loss={v:.4f}")
        else:
            parts.append(f"{k}={v:.4f}")
    return " | ".join(parts)


def set_random_seed(seed: int, deterministic: bool = False) -> None:
    """Set random seeds for reproducible training runs."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.benchmark = True


def seed_worker(worker_id: int) -> None:
    """Seed DataLoader workers from PyTorch's initial worker seed."""
    worker_seed = torch.initial_seed() % 2**32
    random.seed(worker_seed)
    np.random.seed(worker_seed)


def save_checkpoint(
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    metrics: Dict[str, float],
    save_dir: Path,
    is_best: bool = False,
) -> None:
    """Save training checkpoint."""
    checkpoint = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "metrics": metrics,
    }
    save_dir.mkdir(parents=True, exist_ok=True)

    # Save latest
    torch.save(checkpoint, save_dir / "checkpoint_latest.pt")

    # Save best
    if is_best:
        torch.save(checkpoint, save_dir / "checkpoint_best.pt")

    # Save epoch checkpoint periodically
    if epoch % 5 == 0:
        torch.save(checkpoint, save_dir / f"checkpoint_epoch_{epoch:03d}.pt")


# ---------------------------------------------------------------------------
# Core training
# ---------------------------------------------------------------------------

def train_epoch(
    model: StereoBaseline,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    epoch: int,
    writer: Optional[SummaryWriter] = None,
) -> Dict[str, float]:
    """Train for one epoch."""
    model.train()
    total_loss = 0.0
    num_batches = 0

    for batch_idx, batch in enumerate(loader):
        left = batch["left"].to(device)
        right = batch["right"].to(device)
        disp_gt = batch["disp"].to(device)
        mask = batch["mask"].to(device)

        # Forward
        output = model(left, right)
        pred_disp = output["disp"]

        # Loss (on valid pixels only)
        loss = criterion(pred_disp, disp_gt, mask)

        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

        # Log progress
        if batch_idx % 10 == 0:
            global_step = epoch * len(loader) + batch_idx
            print(f"  Epoch {epoch:3d} | Batch {batch_idx:4d}/{len(loader)} | Loss: {loss.item():.4f}")
            if writer is not None:
                writer.add_scalar("train/batch_loss", loss.item(), global_step)

    avg_loss = total_loss / num_batches
    return {"loss": avg_loss}


@torch.no_grad()
def validate(
    model: StereoBaseline,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> Dict[str, float]:
    """Run validation and compute metrics."""
    model.eval()
    total_loss = 0.0
    all_metrics: Dict[str, float] = {"epe": 0.0, "d1": 0.0, "mae": 0.0, "rmse": 0.0}
    num_batches = 0

    for batch in loader:
        left = batch["left"].to(device)
        right = batch["right"].to(device)
        disp_gt = batch["disp"].to(device)
        mask = batch["mask"].to(device)

        # Forward
        output = model(left, right)
        pred_disp = output["disp"]

        # Loss
        loss = criterion(pred_disp, disp_gt, mask)
        total_loss += loss.item()

        # Metrics
        batch_metrics = compute_all_metrics(pred_disp, disp_gt, mask)
        for k in all_metrics:
            all_metrics[k] += batch_metrics[k]

        num_batches += 1

    # Average
    avg_loss = total_loss / num_batches
    for k in all_metrics:
        all_metrics[k] /= num_batches
    all_metrics["loss"] = avg_loss

    return all_metrics


def main(config_path: Optional[str] = None) -> None:
    """Main training entry point."""
    # Parse args
    if config_path is None:
        parser = argparse.ArgumentParser(description="Train stereo CA depth model")
        parser.add_argument("--config", type=Path, required=True, help="Path to YAML config")
        parser.add_argument("--resume", type=Path, default=None, help="Resume from checkpoint")
        args = parser.parse_args()
        config_path = str(args.config)
        resume_path = str(args.resume) if args.resume else None
    else:
        resume_path = None

    # Load config
    config_file = Path(config_path)
    config = load_yaml_config(config_file)

    exp_name = config["experiment_name"]
    seed = int(config.get("seed", 42))
    deterministic = bool(config.get("deterministic", False))
    set_random_seed(seed, deterministic=deterministic)

    print(f"{'='*60}")
    print(f"Experiment: {exp_name}")
    print(f"Config: {config_file}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Seed: {seed} | Deterministic: {deterministic}")
    print(f"{'='*60}")

    # Device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")
    if device.type == "cuda":
        print(f"  GPU: {torch.cuda.get_device_name(0)}")

    # Create dataset
    data_cfg = config["data"]
    train_aug = build_train_transform()
    train_ds = StereoDataset(
        data_root=str(Path(data_cfg["root"]) / data_cfg["train_split"]),
        split="train",
        left_dir=data_cfg.get("left_dir", "left"),
        right_dir=data_cfg.get("right_dir", "right"),
        disp_dir=data_cfg.get("disp_dir", "disp"),
        crop_size=(data_cfg["crop_height"], data_cfg["crop_width"]),
        max_disp=config["model"]["max_disp"],
        transform=train_aug,
    )

    val_ds = StereoDataset(
        data_root=str(Path(data_cfg["root"]) / data_cfg["val_split"]),
        split="val",
        left_dir=data_cfg.get("left_dir", "left"),
        right_dir=data_cfg.get("right_dir", "right"),
        disp_dir=data_cfg.get("disp_dir", "disp"),
        crop_size=None,  # Full image for validation
        max_disp=config["model"]["max_disp"],
    )

    train_cfg = config["training"]
    data_generator = torch.Generator()
    data_generator.manual_seed(seed)

    train_loader = DataLoader(
        train_ds,
        batch_size=train_cfg["batch_size"],
        shuffle=True,
        num_workers=train_cfg.get("num_workers", 0),
        pin_memory=device.type == "cuda",
        worker_init_fn=seed_worker,
        generator=data_generator,
    )

    val_loader = DataLoader(
        val_ds,
        batch_size=train_cfg["batch_size"],
        shuffle=False,
        num_workers=train_cfg.get("num_workers", 0),
        pin_memory=device.type == "cuda",
        worker_init_fn=seed_worker,
        generator=data_generator,
    )

    # Create model
    model = build_model_from_config(config).to(device)
    n_params = count_parameters(model)
    print(f"\nModel parameters: {n_params:,}")

    # Loss
    criterion = DisparitySmoothL1Loss(beta=1.0)

    # Optimizer
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=train_cfg["learning_rate"],
        weight_decay=1e-5,
    )

    # Scheduler: reduce LR on plateau
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=5, min_lr=1e-6
    )

    # Tensorboard
    save_dir = Path(train_cfg["save_dir"])
    writer = SummaryWriter(log_dir=str(save_dir / "logs"))

    # Resume if requested
    start_epoch = 0
    best_epe = float("inf")
    if resume_path and Path(resume_path).exists():
        checkpoint = torch.load(resume_path, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        start_epoch = checkpoint["epoch"] + 1
        best_epe = checkpoint["metrics"].get("epe", float("inf"))
        print(f"Resumed from epoch {start_epoch}, best EPE: {best_epe:.3f}")

    # Training loop
    num_epochs = train_cfg["epochs"]

    print(f"\n{'='*60}")
    print(f"Starting training: {num_epochs} epochs (starting from {start_epoch})")
    print(f"{'='*60}\n")

    for epoch in range(start_epoch, num_epochs):
        epoch_start = time.time()

        # Train
        train_metrics = train_epoch(
            model, train_loader, criterion, optimizer, device, epoch, writer
        )

        # Validate
        val_metrics = validate(model, val_loader, criterion, device)

        # Scheduler step
        scheduler.step(val_metrics["epe"])
        current_lr = optimizer.param_groups[0]["lr"]

        # Log
        epoch_time = time.time() - epoch_start
        is_best = val_metrics["epe"] < best_epe
        if is_best:
            best_epe = val_metrics["epe"]

        print(f"\n--- Epoch {epoch:3d} Summary ---")
        print(f"  Train Loss: {train_metrics['loss']:.4f}")
        print(f"  Val   {format_metrics(val_metrics)}")
        print(f"  LR: {current_lr:.2e} | Time: {epoch_time:.1f}s | Best EPE: {best_epe:.3f} {'*' if is_best else ''}")
        print()

        # Tensorboard
        if writer is not None:
            writer.add_scalar("train/epoch_loss", train_metrics["loss"], epoch)
            for k, v in val_metrics.items():
                writer.add_scalar(f"val/{k}", v, epoch)
            writer.add_scalar("train/lr", current_lr, epoch)

        # Save checkpoint
        save_checkpoint(
            model, optimizer, epoch, val_metrics, save_dir, is_best=is_best
        )

    # Save final config and results
    config["results"] = {
        "best_epe": best_epe,
        "num_params": n_params,
    }
    with open(save_dir / "config.yaml", "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

    print(f"\n{'='*60}")
    print(f"Training complete!")
    print(f"  Best EPE: {best_epe:.3f}")
    print(f"  Model saved to: {save_dir}")
    print(f"{'='*60}")

    writer.close()


if __name__ == "__main__":
    main()
