"""Lightweight stereo baseline network.

Combines:
  - Shared-weight feature extractor (with optional Coordinate Attention)
  - Absolute difference cost volume
  - 2D CNN cost aggregation
  - Softmax disparity regression
  - Bilinear upsampling to original resolution
"""

from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn
import torch.nn.functional as F

from .attention_modules import AttentionConfig
from .cost_volume import StereoCostPipeline
from .feature_extractor import create_feature_extractor
from .refinement import create_refinement_module


class StereoBaseline(nn.Module):
    """Complete lightweight stereo disparity estimation network.

    Pipeline:
        left, right images (B, 3, H, W)
        → shared feature extractor → (B, 64, H/4, W/4) each
        → cost volume → (B, 64, 16, H/4, W/4)
        → 2D aggregation → (B, 16, H/4, W/4)
        → softmax regression → (B, 1, H/4, W/4)
        → upsample ×4 → (B, 1, H, W)
        → multiply by 4 → final disparity

    Args:
        max_disp: Maximum disparity at original resolution.
        shallow_ch: Feature channels at H/2 scale.
        deep_ch: Feature channels at H/4 scale (used for cost volume).
        shallow_attention: Attention module config at H/2.
        deep_attention: Attention module config at H/4.
        use_ca_shallow: Backward-compatible shortcut for shallow CA.
        use_ca_deep: Backward-compatible shortcut for deep CA.
        agg_channels: Hidden channels in cost aggregator.
        cost_volume_type: Cost volume type, ``absdiff`` or ``acv_lite``.
        cost_volume_cfg: Optional cost volume settings.
        cost_aggregation_type: Cost aggregation type, ``2d`` or ``light3d``.
        cost_aggregation_cfg: Optional aggregation settings.
    """

    def __init__(
        self,
        max_disp: int = 64,
        shallow_ch: int = 32,
        deep_ch: int = 64,
        shallow_attention: AttentionConfig = None,
        deep_attention: AttentionConfig = None,
        use_ca_shallow: bool = False,
        use_ca_deep: bool = False,
        agg_channels: int = 32,
        cost_volume_type: str = "absdiff",
        cost_volume_cfg: Dict | None = None,
        cost_aggregation_type: str = "2d",
        cost_aggregation_cfg: Dict | None = None,
        use_refinement: bool = False,
        refinement_hidden_channels: int = 32,
        refinement_num_blocks: int = 3,
    ) -> None:
        super().__init__()
        self.max_disp = max_disp
        self.scale_factor = 4  # H/4 → H
        self.use_refinement = use_refinement

        # Shared-weight feature extractor
        self.feature_extractor = create_feature_extractor(
            in_channels=3,
            shallow_ch=shallow_ch,
            deep_ch=deep_ch,
            shallow_attention=shallow_attention,
            deep_attention=deep_attention,
            use_ca_shallow=use_ca_shallow,
            use_ca_deep=use_ca_deep,
        )

        # Cost volume + aggregation + regression
        self.cost_pipeline = StereoCostPipeline(
            feature_channels=deep_ch,
            max_disp=max_disp,
            agg_channels=agg_channels,
            volume_type=cost_volume_type,
            volume_cfg=cost_volume_cfg,
            aggregation_type=cost_aggregation_type,
            aggregation_cfg=cost_aggregation_cfg,
        )

        # Edge-aware refinement
        self.refinement = create_refinement_module(
            use_refinement=use_refinement,
            hidden_channels=refinement_hidden_channels,
            num_blocks=refinement_num_blocks,
        )

    def forward(
        self, left: torch.Tensor, right: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """Forward pass.

        Args:
            left: Left image (B, 3, H, W), values in [0, 1].
            right: Right image (B, 3, H, W), values in [0, 1].

        Returns:
            dict with:
                'disp': final disparity at full resolution (B, 1, H, W)
                'disp_low': disparity at H/4 resolution (B, 1, H/4, W/4)
                'features': dict of {'left': {...}, 'right': {...}}
        """
        # Feature extraction (shared weights)
        left_feats, right_feats = self.feature_extractor.forward_stereo(left, right)

        # Cost volume → aggregation → regression
        disp_low = self.cost_pipeline(left_feats["deep"], right_feats["deep"])

        # Upsample to original resolution
        H_out, W_out = left.shape[2], left.shape[3]
        disp_full = F.interpolate(
            disp_low,
            size=(H_out, W_out),
            mode="bilinear",
            align_corners=False,
        )

        # Scale: disparity at H/4 was in [0, max_disp/4), multiply by 4
        disp_full = disp_full * self.scale_factor

        # Apply edge-aware refinement if enabled
        if self.use_refinement:
            disp_full = self.refinement(disp_full, left)

        return {
            "disp": disp_full,
            "disp_low": disp_low,
            "features": {"left": left_feats, "right": right_feats},
        }


# ---------------------------------------------------------------------------
# Factory functions for each experiment configuration
# ---------------------------------------------------------------------------

def create_baseline(
    max_disp: int = 64,
    shallow_ch: int = 32,
    deep_ch: int = 64,
) -> StereoBaseline:
    """Create baseline model (no CA)."""
    return StereoBaseline(
        max_disp=max_disp,
        shallow_ch=shallow_ch,
        deep_ch=deep_ch,
        shallow_attention="none",
        deep_attention="none",
    )


def create_ca_shallow(
    max_disp: int = 64,
    shallow_ch: int = 32,
    deep_ch: int = 64,
) -> StereoBaseline:
    """Create model with CA at shallow position only."""
    return StereoBaseline(
        max_disp=max_disp,
        shallow_ch=shallow_ch,
        deep_ch=deep_ch,
        shallow_attention="ca",
        deep_attention="none",
    )


def create_ca_deep(
    max_disp: int = 64,
    shallow_ch: int = 32,
    deep_ch: int = 64,
) -> StereoBaseline:
    """Create model with CA at deep position only."""
    return StereoBaseline(
        max_disp=max_disp,
        shallow_ch=shallow_ch,
        deep_ch=deep_ch,
        shallow_attention="none",
        deep_attention="ca",
    )


def create_ca_full(
    max_disp: int = 64,
    shallow_ch: int = 32,
    deep_ch: int = 64,
) -> StereoBaseline:
    """Create model with CA at both shallow and deep positions."""
    return StereoBaseline(
        max_disp=max_disp,
        shallow_ch=shallow_ch,
        deep_ch=deep_ch,
        shallow_attention="ca",
        deep_attention="ca",
    )


# Map config names to factory functions
MODEL_FACTORIES = {
    "baseline": create_baseline,
    "ca_shallow": create_ca_shallow,
    "ca_deep": create_ca_deep,
    "ca_full": create_ca_full,
}
