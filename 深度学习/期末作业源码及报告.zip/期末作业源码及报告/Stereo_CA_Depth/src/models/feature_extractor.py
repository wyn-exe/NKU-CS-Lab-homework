"""Lightweight shared-weight feature extractor for stereo matching.

Design follows the experiment plan: a simple CNN with two downsampling
stages and optional Coordinate Attention insertion points.

Architecture:
    Input (B, 3, H, W)
    → Conv-BN-ReLU, stride=2, C=32          → shallow_feat (H/2)
    → [Optional CA-shallow]
    → ResBlock, C=32
    → Conv-BN-ReLU, stride=2, C=64          → deep_feat (H/4)
    → [Optional CA-deep]
    → ResBlock, C=64
    → Output (B, 64, H/4, W/4)
"""

from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn

from .attention_modules import AttentionConfig, build_attention


class ConvBNReLU(nn.Module):
    """Conv → BatchNorm → ReLU."""

    def __init__(
        self,
        in_ch: int,
        out_ch: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: int = 1,
    ) -> None:
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.relu(self.bn(self.conv(x)))


class LightweightResBlock(nn.Module):
    """Lightweight residual block with optional depthwise separable conv.

    Uses two 3×3 convolutions with a residual connection.
    """

    def __init__(self, channels: int, expansion: float = 1.0) -> None:
        super().__init__()
        hidden = int(channels * expansion)

        self.conv1 = nn.Conv2d(channels, hidden, 3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(hidden)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(hidden, channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = self.relu(out + identity)
        return out


class StereoFeatureExtractor(nn.Module):
    """Shared-weight CNN feature extractor for stereo matching.

    Left and right images go through the same extractor to ensure
    features live in the same representational space.

    Args:
        in_channels: Input channels (3 for RGB).
        shallow_ch: Channels after first downsampling (H/2 scale).
        deep_ch: Channels after second downsampling (H/4 scale).
        shallow_attention: Attention module at the H/2 feature stage.
        deep_attention: Attention module at the H/4 feature stage.
        use_ca_shallow: Backward-compatible shortcut for shallow CA.
        use_ca_deep: Backward-compatible shortcut for deep CA.
    """

    def __init__(
        self,
        in_channels: int = 3,
        shallow_ch: int = 32,
        deep_ch: int = 64,
        shallow_attention: AttentionConfig = None,
        deep_attention: AttentionConfig = None,
        use_ca_shallow: bool = False,
        use_ca_deep: bool = False,
    ) -> None:
        super().__init__()
        if use_ca_shallow and shallow_attention is None:
            shallow_attention = "ca"
        if use_ca_deep and deep_attention is None:
            deep_attention = "ca"

        # --- Stage 1: H → H/2, C = shallow_ch ---
        self.stage1_down = ConvBNReLU(in_channels, shallow_ch, stride=2)

        # Optional attention at shallow position
        self.attn_shallow = build_attention(shallow_attention, shallow_ch)

        # --- Stage 2: H/2 → H/4, C = deep_ch ---
        self.stage1_res = LightweightResBlock(shallow_ch)
        self.stage2_down = ConvBNReLU(shallow_ch, deep_ch, stride=2)

        # Optional attention at deep position
        self.attn_deep = build_attention(deep_attention, deep_ch)

        # Final processing
        self.stage2_res = LightweightResBlock(deep_ch)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Extract features from a single image.

        Args:
            x: Image tensor of shape (B, 3, H, W).

        Returns:
            dict with keys:
                'shallow': features at H/2 scale (before CA)
                'deep': features at H/4 scale (final output)
        """
        # Stage 1: H → H/2
        f1 = self.stage1_down(x)  # (B, 32, H/2, W/2)
        shallow_feat = f1

        # Optional attention at shallow position
        f1 = self.attn_shallow(f1)

        # Stage 2: H/2 → H/4
        f1 = self.stage1_res(f1)  # (B, 32, H/2, W/2)
        f2 = self.stage2_down(f1)  # (B, 64, H/4, W/4)
        deep_feat = f2

        # Optional attention at deep position
        f2 = self.attn_deep(f2)

        # Final refinement
        f2 = self.stage2_res(f2)  # (B, 64, H/4, W/4)

        return {
            "shallow": shallow_feat,
            "deep": f2,
        }

    def forward_stereo(
        self, left: torch.Tensor, right: torch.Tensor
    ) -> Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor]]:
        """Extract features from a stereo pair.

        Args:
            left: Left image (B, 3, H, W).
            right: Right image (B, 3, H, W).

        Returns:
            (left_features, right_features) tuple of dicts.
        """
        return self.forward(left), self.forward(right)


def create_feature_extractor(
    in_channels: int = 3,
    shallow_ch: int = 32,
    deep_ch: int = 64,
    shallow_attention: AttentionConfig = None,
    deep_attention: AttentionConfig = None,
    use_ca_shallow: bool = False,
    use_ca_deep: bool = False,
) -> StereoFeatureExtractor:
    """Factory function to create a feature extractor.

    Args:
        in_channels: Input channels.
        shallow_ch: Channels at H/2 scale.
        deep_ch: Channels at H/4 scale.
        shallow_attention: Attention module config at H/2.
        deep_attention: Attention module config at H/4.
        use_ca_shallow: Enable CA at shallow position.
        use_ca_deep: Enable CA at deep position.

    Returns:
        Configured StereoFeatureExtractor.
    """
    return StereoFeatureExtractor(
        in_channels=in_channels,
        shallow_ch=shallow_ch,
        deep_ch=deep_ch,
        shallow_attention=shallow_attention,
        deep_attention=deep_attention,
        use_ca_shallow=use_ca_shallow,
        use_ca_deep=use_ca_deep,
    )
