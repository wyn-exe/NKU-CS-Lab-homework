"""Edge-aware refinement module inspired by StereoNet.

Refines upsampled disparity using left image as guidance to preserve edges
and recover fine details.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class EdgeAwareRefinement(nn.Module):
    """StereoNet-style edge-aware disparity refinement.

    Takes upsampled coarse disparity and left RGB image, predicts
    residual disparity using a lightweight CNN, then applies residual
    correction to get refined disparity.

    Pipeline:
        disp_up (B, 1, H, W) + left_img (B, 3, H, W)
        → concatenate → (B, 4, H, W)
        → small CNN → (B, 1, H, W) residual_disp
        → refined_disp = disp_up + residual_disp

    Args:
        in_channels: Input channels (disp + RGB = 4).
        hidden_channels: Intermediate channels in the CNN.
        num_blocks: Number of residual blocks in the refinement network.
    """

    def __init__(
        self,
        in_channels: int = 4,
        hidden_channels: int = 16,
        num_blocks: int = 2,
    ) -> None:
        super().__init__()

        # Normalize input disparity and image
        # Initial convolution to fuse disp and RGB
        self.init_conv = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
        )

        # Residual blocks for refinement
        blocks = []
        for _ in range(num_blocks):
            blocks.append(ResidualBlock(hidden_channels))
        self.res_blocks = nn.Sequential(*blocks)

        # Output residual disparity - with small initialization
        self.out_conv = nn.Conv2d(hidden_channels, 1, 3, padding=1)

        # Initialize output layer with near-zero weights to start as identity
        nn.init.constant_(self.out_conv.weight, 0)
        if self.out_conv.bias is not None:
            nn.init.constant_(self.out_conv.bias, 0)

        # Initialize rest of the network
        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if m == self.out_conv:  # Skip output conv, already initialized
                continue
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(
        self, disp_up: torch.Tensor, left_img: torch.Tensor
    ) -> torch.Tensor:
        """Refine coarse disparity.

        Args:
            disp_up: Upsampled disparity at full resolution (B, 1, H, W).
            left_img: Left RGB image (B, 3, H, W), values in [0, 1].

        Returns:
            Refined disparity (B, 1, H, W).
        """
        # Concatenate disparity and RGB
        x = torch.cat([disp_up, left_img], dim=1)  # (B, 4, H, W)

        # Initial fusion
        x = self.init_conv(x)

        # Residual refinement
        x = self.res_blocks(x)

        # Predict residual - apply tanh to limit residual range
        residual = self.out_conv(x)
        residual = torch.tanh(residual) * 3.0  # Limit residual to [-3, 3]

        # Apply residual correction
        disp_refined = disp_up + residual

        return disp_refined


class ResidualBlock(nn.Module):
    """Simple residual block for refinement network."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out, inplace=True)
        out = self.conv2(out)
        out = self.bn2(out)
        out += identity
        out = F.relu(out, inplace=True)
        return out


def create_refinement_module(
    use_refinement: bool = False,
    hidden_channels: int = 16,
    num_blocks: int = 2,
) -> nn.Module:
    """Factory function for refinement module.

    Args:
        use_refinement: Whether to use refinement. If False, returns Identity.
        hidden_channels: Hidden channels in refinement network.
        num_blocks: Number of residual blocks.

    Returns:
        Refinement module or Identity.
    """
    if not use_refinement:
        return nn.Identity()
    return EdgeAwareRefinement(
        in_channels=4,
        hidden_channels=hidden_channels,
        num_blocks=num_blocks,
    )
