"""Attention module registry for feature extraction blocks.

New attention modules should be added here and exposed through
``ATTENTION_REGISTRY``. Model code then selects modules from config instead of
hard-coding one boolean flag per experiment.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Mapping, Optional, Union

import torch
import torch.nn as nn

from .ca_module import CoordAtt


AttentionConfig = Optional[Union[str, Mapping[str, Any]]]
AttentionBuilder = Callable[..., nn.Module]


class SqueezeExcitation(nn.Module):
    """Lightweight SE channel attention block."""

    def __init__(self, channels: int, reduction: int = 16) -> None:
        super().__init__()
        hidden = max(8, channels // reduction)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, hidden, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, kernel_size=1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.fc(self.pool(x))


class EfficientChannelAttention(nn.Module):
    """ECA channel attention block with a 1D local channel interaction."""

    def __init__(self, channels: int, kernel_size: int = 3) -> None:
        super().__init__()
        if kernel_size % 2 == 0:
            raise ValueError("ECA kernel_size must be odd")
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(
            1,
            1,
            kernel_size=kernel_size,
            padding=(kernel_size - 1) // 2,
            bias=False,
        )
        self.act = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.pool(x).squeeze(-1).transpose(1, 2)
        y = self.conv(y).transpose(1, 2).unsqueeze(-1)
        return x * self.act(y)


def _identity_builder(channels: int, **kwargs: Any) -> nn.Module:
    return nn.Identity()


def _ca_builder(channels: int, reduction: int = 16, **kwargs: Any) -> nn.Module:
    return CoordAtt(channels, reduction=reduction)


def _se_builder(channels: int, reduction: int = 16, **kwargs: Any) -> nn.Module:
    return SqueezeExcitation(channels, reduction=reduction)


def _eca_builder(channels: int, kernel_size: int = 3, **kwargs: Any) -> nn.Module:
    return EfficientChannelAttention(channels, kernel_size=kernel_size)


ATTENTION_REGISTRY: Dict[str, AttentionBuilder] = {
    "none": _identity_builder,
    "identity": _identity_builder,
    "ca": _ca_builder,
    "coordatt": _ca_builder,
    "coordinate_attention": _ca_builder,
    "se": _se_builder,
    "squeeze_excitation": _se_builder,
    "eca": _eca_builder,
}


def normalize_attention_config(config: AttentionConfig) -> Dict[str, Any]:
    """Normalize a string/dict attention config to a builder-ready dict."""
    if config is None or config is False:
        return {"type": "none"}
    if isinstance(config, str):
        return {"type": config}
    if not isinstance(config, Mapping):
        raise TypeError(f"Unsupported attention config: {config!r}")

    normalized = dict(config)
    if "name" in normalized and "type" not in normalized:
        normalized["type"] = normalized.pop("name")
    normalized.setdefault("type", "none")
    return normalized


def build_attention(config: AttentionConfig, channels: int) -> nn.Module:
    """Build an attention module from config.

    Examples:
        ``"ca"``
        ``{"type": "se", "reduction": 8}``
        ``{"type": "eca", "kernel_size": 5}``
    """
    cfg = normalize_attention_config(config)
    module_type = str(cfg.pop("type")).lower()
    if module_type not in ATTENTION_REGISTRY:
        known = ", ".join(sorted(ATTENTION_REGISTRY))
        raise ValueError(f"Unknown attention type '{module_type}'. Known: {known}")
    return ATTENTION_REGISTRY[module_type](channels=channels, **cfg)
