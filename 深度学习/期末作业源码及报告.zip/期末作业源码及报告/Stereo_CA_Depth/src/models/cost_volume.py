"""Cost volume construction and aggregation for stereo matching.

Uses absolute difference cost volume (lightweight) followed by
2D CNN aggregation, then softmax-based disparity regression.
"""

from __future__ import annotations

from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .acv_lite import ACVLiteCostVolume


class AbsDiffCostVolume(nn.Module):
    """Absolute difference cost volume.

    For each candidate disparity d:
        shift right features d pixels to the left,
        compute abs(F_left - shifted_F_right),
        stack all differences.

    Operates at feature resolution (H/4 × W/4).

    Args:
        max_disp: Maximum disparity at original resolution.
            At H/4 resolution, num candidates = max_disp // 4.
    """

    def __init__(self, max_disp: int = 64, invalid_cost: float = 10.0) -> None:
        super().__init__()
        self.max_disp = max_disp
        self.invalid_cost = invalid_cost

    @property
    def num_candidates(self) -> int:
        """Number of disparity candidates at H/4 resolution."""
        return self.max_disp // 4

    def forward(
        self, left_feat: torch.Tensor, right_feat: torch.Tensor
    ) -> torch.Tensor:
        """Build cost volume from left and right features.

        Args:
            left_feat: (B, C, H_f, W_f) left image features.
            right_feat: (B, C, H_f, W_f) right image features.

        Returns:
            Cost volume of shape (B, C, D, H_f, W_f) where D = max_disp//4.
            Cost[i, c, d, y, x] = |F_left[c, y, x] - F_right[c, y, x+d]|
        """
        B, C, H, W = left_feat.shape
        D = self.num_candidates
        cost_volume = []

        for d in range(D):
            if d == 0:
                diff = torch.abs(left_feat - right_feat)
            else:
                # Shift right features d pixels to the left
                # left[:, d:] aligns with right[:, :-d]
                diff_left = left_feat[:, :, :, d:]  # (B, C, H, W-d)
                diff_right = right_feat[:, :, :, : W - d]  # (B, C, H, W-d)
                diff = torch.abs(diff_left - diff_right)

                # Pad invalid left-border candidates with a high cost.
                # Zero would mean "perfect match" because lower cost is better.
                diff = F.pad(
                    diff,
                    (d, 0, 0, 0),
                    mode="constant",
                    value=self.invalid_cost,
                )

            cost_volume.append(diff)

        # Stack along disparity dimension: (B, C, D, H, W)
        cost = torch.stack(cost_volume, dim=2)
        return cost


class CostAggregator2D(nn.Module):
    """Lightweight 2D CNN cost aggregation.

    Processes each disparity slice independently with small 2D convs.

    Args:
        in_channels: Feature channel dimension.
        hidden_channels: Internal channel count after reduction.
    """

    def __init__(self, in_channels: int = 64, hidden_channels: int = 32) -> None:
        super().__init__()
        # First reduce feature channels per disparity
        self.reduce = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
        )

        # Aggregate spatial context
        self.agg = nn.Sequential(
            nn.Conv2d(hidden_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
        )

        # Per-slice channel mixing. This does not mix information across D.
        self.channel_mix = nn.Sequential(
            nn.Conv2d(hidden_channels, hidden_channels, 1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
        )

        # Output: 1 channel per disparity = matching cost
        self.cost_out = nn.Conv2d(hidden_channels, 1, 3, padding=1, bias=False)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, cost_volume: torch.Tensor) -> torch.Tensor:
        """Aggregate cost volume and produce matching costs.

        Args:
            cost_volume: (B, C, D, H, W) from AbsDiffCostVolume.

        Returns:
            Matching costs of shape (B, D, H, W). Lower = better match.
        """
        B, C, D, H, W = cost_volume.shape

        # Process each disparity independently
        # Reshape: (B, C, D, H, W) → (B*D, C, H, W)
        cost_reshaped = cost_volume.permute(0, 2, 1, 3, 4).reshape(B * D, C, H, W)

        # Reduce channels
        x = self.reduce(cost_reshaped)  # (B*D, hidden, H, W)

        # Aggregate
        x = self.agg(x)  # (B*D, hidden, H, W)

        # Per-slice channel mixing
        x = self.channel_mix(x)  # (B*D, hidden, H, W)

        # Output matching cost
        x = self.cost_out(x)  # (B*D, 1, H, W)

        # Reshape back: (B*D, 1, H, W) → (B, D, H, W)
        costs = x.reshape(B, D, H, W)
        return costs


class CostAggregator3DLight(nn.Module):
    """Lightweight 3D cost aggregation with explicit disparity mixing.

    Unlike ``CostAggregator2D``, this module keeps the disparity dimension
    inside 3D convolutions, so neighboring disparity candidates can exchange
    information before soft-argmin regression.
    """

    def __init__(self, in_channels: int = 64, hidden_channels: int = 8) -> None:
        super().__init__()
        self.reduce = nn.Sequential(
            nn.Conv3d(in_channels, hidden_channels, kernel_size=1, bias=False),
            nn.BatchNorm3d(hidden_channels),
            nn.ReLU(inplace=True),
        )
        self.agg = nn.Sequential(
            nn.Conv3d(hidden_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm3d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(hidden_channels, hidden_channels, 3, padding=1, bias=False),
            nn.BatchNorm3d(hidden_channels),
            nn.ReLU(inplace=True),
        )
        self.cost_out = nn.Conv3d(hidden_channels, 1, 3, padding=1, bias=False)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, cost_volume: torch.Tensor) -> torch.Tensor:
        """Aggregate cost volume and produce matching costs.

        Args:
            cost_volume: (B, C, D, H, W).

        Returns:
            Matching costs of shape (B, D, H, W). Lower = better match.
        """
        x = self.reduce(cost_volume)
        x = self.agg(x)
        x = self.cost_out(x)
        return x.squeeze(1)


class DisparityRegression(nn.Module):
    """Softmax-based disparity regression.

    Applies softmax over the disparity dimension to obtain a probability
    distribution, then computes the expected disparity via soft argmin.

    Args:
        max_disp: Maximum disparity at original resolution.
    """

    def __init__(self, max_disp: int = 64) -> None:
        super().__init__()
        self.max_disp = max_disp
        self.num_candidates = max_disp // 4
        # Candidate disparity values at H/4 resolution
        self.register_buffer(
            "candidates",
            torch.arange(self.num_candidates, dtype=torch.float32),
        )

    def forward(self, costs: torch.Tensor) -> torch.Tensor:
        """Regress disparity from matching costs.

        Args:
            costs: (B, D, H, W) matching costs (lower = better match).

        Returns:
            Predicted disparity at H/4 resolution: (B, 1, H, W).
            Values in [0, max_disp/4).
        """
        # Negate costs: higher probability for lower cost
        # Softmax over disparity dimension
        prob = F.softmax(-costs, dim=1)  # (B, D, H, W)

        # Weighted sum: expected disparity
        # candidates shape: (D,) → (1, D, 1, 1)
        cand = self.candidates.view(1, -1, 1, 1)
        disp = (prob * cand).sum(dim=1, keepdim=True)  # (B, 1, H, W)
        return disp


class StereoCostPipeline(nn.Module):
    """Complete cost volume → aggregation → regression pipeline.

    Args:
        feature_channels: Number of channels in feature maps.
        max_disp: Maximum disparity at original resolution.
        agg_channels: Hidden channels in cost aggregator.
        volume_type: Cost volume type, ``absdiff`` or ``acv_lite``.
        volume_cfg: Optional cost volume settings.
        aggregation_type: Cost aggregation type, ``2d`` or ``light3d``.
        aggregation_cfg: Optional aggregation settings.
    """

    def __init__(
        self,
        feature_channels: int = 64,
        max_disp: int = 64,
        agg_channels: int = 32,
        volume_type: str = "absdiff",
        volume_cfg: dict | None = None,
        aggregation_type: str = "2d",
        aggregation_cfg: dict | None = None,
    ) -> None:
        super().__init__()
        volume_cfg = dict(volume_cfg or {})
        volume_type = volume_type.lower()
        if volume_type in {"absdiff", "abs_diff", "baseline"}:
            self.cost_volume = AbsDiffCostVolume(max_disp=max_disp, **volume_cfg)
            volume_channels = feature_channels
        elif volume_type in {"acv_lite", "acvlite"}:
            self.cost_volume = ACVLiteCostVolume(max_disp=max_disp, **volume_cfg)
            volume_channels = feature_channels + self.cost_volume.extra_channels
        else:
            raise ValueError(f"Unknown cost volume type: {volume_type}")

        aggregation_cfg = dict(aggregation_cfg or {})
        aggregation_type = aggregation_type.lower()
        if "hidden_channels" not in aggregation_cfg:
            aggregation_cfg["hidden_channels"] = agg_channels

        if aggregation_type in {"2d", "slice2d", "baseline"}:
            self.aggregator = CostAggregator2D(in_channels=volume_channels, **aggregation_cfg)
        elif aggregation_type in {"light3d", "3d_light", "3d"}:
            self.aggregator = CostAggregator3DLight(in_channels=volume_channels, **aggregation_cfg)
        else:
            raise ValueError(f"Unknown cost aggregation type: {aggregation_type}")

        self.volume_type = volume_type
        self.aggregation_type = aggregation_type
        self.regression = DisparityRegression(max_disp=max_disp)

    def forward(
        self, left_feat: torch.Tensor, right_feat: torch.Tensor
    ) -> torch.Tensor:
        """Build cost volume, aggregate, and regress disparity.

        Args:
            left_feat: (B, C, H_f, W_f) left features.
            right_feat: (B, C, H_f, W_f) right features.

        Returns:
            Disparity at feature resolution: (B, 1, H_f, W_f).
        """
        cost = self.cost_volume(left_feat, right_feat)  # (B, C, D, Hf, Wf)
        costs = self.aggregator(cost)  # (B, D, Hf, Wf)
        disp_low = self.regression(costs)  # (B, 1, Hf, Wf)
        return disp_low
