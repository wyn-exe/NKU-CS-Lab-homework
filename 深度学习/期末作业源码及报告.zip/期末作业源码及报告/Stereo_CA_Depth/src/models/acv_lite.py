"""ACV-lite cost volume for lightweight stereo matching.

This is a compact project-friendly variant inspired by ACVNet. It does not
try to reproduce the full network. Instead, it adds group-wise
correlation-derived disparity priors to the existing absolute-difference cost
volume.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ACVLiteCostVolume(nn.Module):
    """Absolute-difference volume plus group-wise correlation priors.

    For each candidate disparity, the module computes:
      1. absolute feature difference, as in the baseline;
      2. normalized left/right group-wise feature correlation;
      3. a softmax distribution over disparity candidates for each group.

    The attention priors are appended as extra channels per disparity slice.
    A learnable gate controls prior strength so the model can start close to
    the baseline and gradually use the ACV-lite signal during training.
    """

    def __init__(
        self,
        max_disp: int = 64,
        invalid_cost: float = 10.0,
        temperature: float = 0.07,
        groups: int = 8,
        gate_init: float = 0.1,
    ) -> None:
        super().__init__()
        self.max_disp = max_disp
        self.invalid_cost = invalid_cost
        self.temperature = temperature
        self.groups = groups
        self.gate = nn.Parameter(torch.tensor(float(gate_init)))

    @property
    def num_candidates(self) -> int:
        return self.max_disp // 4

    @property
    def extra_channels(self) -> int:
        return self.groups

    def _normalize_grouped(self, feat: torch.Tensor) -> torch.Tensor:
        """Normalize features within each channel group."""
        B, C, H, W = feat.shape
        if C % self.groups != 0:
            raise ValueError(f"feature channels ({C}) must be divisible by groups ({self.groups})")
        feat = feat.view(B, self.groups, C // self.groups, H, W)
        return F.normalize(feat, p=2, dim=2)

    def forward(self, left_feat: torch.Tensor, right_feat: torch.Tensor) -> torch.Tensor:
        """Build ACV-lite volume.

        Args:
            left_feat: (B, C, H, W) left features.
            right_feat: (B, C, H, W) right features.

        Returns:
            Cost volume of shape (B, C+groups, D, H, W). The extra channels
            store gated ``1 - attention`` priors, where lower values indicate
            stronger group-wise matches.
        """
        B, C, H, W = left_feat.shape
        D = self.num_candidates
        diff_slices = []
        corr_slices = []

        left_norm = self._normalize_grouped(left_feat)
        right_norm = self._normalize_grouped(right_feat)

        for d in range(D):
            if d == 0:
                diff = torch.abs(left_feat - right_feat)
                corr = (left_norm * right_norm).sum(dim=2)
            else:
                diff_left = left_feat[:, :, :, d:]
                diff_right = right_feat[:, :, :, : W - d]
                diff = torch.abs(diff_left - diff_right)
                diff = F.pad(diff, (d, 0, 0, 0), mode="constant", value=self.invalid_cost)

                corr_left = left_norm[:, :, :, :, d:]
                corr_right = right_norm[:, :, :, :, : W - d]
                corr = (corr_left * corr_right).sum(dim=2)
                corr = F.pad(corr, (d, 0, 0, 0), mode="constant", value=-1.0)

            diff_slices.append(diff)
            corr_slices.append(corr)

        diff_volume = torch.stack(diff_slices, dim=2)  # (B, C, D, H, W)
        corr_volume = torch.stack(corr_slices, dim=2)  # (B, groups, D, H, W)

        logits = corr_volume / max(self.temperature, 1e-6)
        attention = F.softmax(logits, dim=2)  # (B, groups, D, H, W)
        attention_cost = (1.0 - attention) * self.gate

        return torch.cat([diff_volume, attention_cost], dim=1)
