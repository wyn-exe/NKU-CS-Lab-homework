"""Stereo matching models."""

from .attention_modules import (
    ATTENTION_REGISTRY,
    EfficientChannelAttention,
    SqueezeExcitation,
    build_attention,
)
from .acv_lite import ACVLiteCostVolume
from .ca_module import CoordAtt, create_ca_block
from .cost_volume import (
    AbsDiffCostVolume,
    CostAggregator2D,
    CostAggregator3DLight,
    DisparityRegression,
    StereoCostPipeline,
)
from .feature_extractor import StereoFeatureExtractor, create_feature_extractor
from .stereo_baseline import (
    MODEL_FACTORIES,
    StereoBaseline,
    create_baseline,
    create_ca_deep,
    create_ca_full,
    create_ca_shallow,
)

__all__ = [
    "CoordAtt",
    "create_ca_block",
    "ATTENTION_REGISTRY",
    "EfficientChannelAttention",
    "SqueezeExcitation",
    "build_attention",
    "ACVLiteCostVolume",
    "AbsDiffCostVolume",
    "CostAggregator2D",
    "CostAggregator3DLight",
    "DisparityRegression",
    "StereoCostPipeline",
    "StereoFeatureExtractor",
    "create_feature_extractor",
    "StereoBaseline",
    "create_baseline",
    "create_ca_shallow",
    "create_ca_deep",
    "create_ca_full",
    "MODEL_FACTORIES",
]
