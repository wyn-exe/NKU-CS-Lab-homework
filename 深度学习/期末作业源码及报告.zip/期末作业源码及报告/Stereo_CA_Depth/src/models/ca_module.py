"""Coordinate Attention module.

Implements the Coordinate Attention block from:
  "Coordinate Attention for Efficient Mobile Network Design" (CVPR 2021)
  https://arxiv.org/abs/2103.02907

Coordinate Attention encodes both channel relationships and
direction-aware positional information by decomposing global pooling
into a pair of 1D feature encoding operations along horizontal and
vertical spatial directions. This is particularly relevant for stereo
matching, where horizontal disparity search dominates.
"""

from __future__ import annotations

import torch
import torch.nn as nn


class CoordAtt(nn.Module):
    """Coordinate Attention block.

    Args:
        inp: Input channel dimension.
        reduction: Channel reduction ratio for the middle bottleneck.
            Smaller values preserve more information but add parameters.
    """

    def __init__(self, inp: int, reduction: int = 16) -> None:
        super().__init__()
        oup = inp
        mip = max(8, inp // reduction)

        # Horizontal and vertical average pooling
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        # Shared 1x1 conv to reduce channels after concatenation
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, bias=False)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.Hardswish(inplace=True)

        # Separate 1x1 convs to expand back for H and W branches
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, bias=False)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, bias=False)

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Input tensor of shape (B, C, H, W).

        Returns:
            Output tensor of shape (B, C, H, W), same as input.
        """
        identity = x
        B, C, H, W = x.shape

        # Horizontal pool: (B, C, H, 1)
        x_h = self.pool_h(x)
        # Vertical pool: (B, C, 1, W)
        x_w = self.pool_w(x)

        # Transpose x_w to (B, C, W, 1) so we can concat along H dim,
        # then transpose back. Actually: permute x_w to (B, C, W, 1),
        # concat with x_h along dim=2 (now both have height dim of H+W),
        # Wait — shapes: x_h is (B, C, H, 1), x_w is (B, C, 1, W).
        # Transpose x_w to (B, C, W, 1), then cat with x_h along dim=2:
        # → (B, C, H+W, 1)
        x_w = x_w.permute(0, 1, 3, 2)  # (B, C, W, 1)
        x_cat = torch.cat([x_h, x_w], dim=2)  # (B, C, H+W, 1)

        # Shared transform
        x_cat = self.conv1(x_cat)
        x_cat = self.bn1(x_cat)
        x_cat = self.act(x_cat)

        # Split back into H and W branches
        x_h, x_w = torch.split(x_cat, [H, W], dim=2)
        # x_w needs to be transposed back: (B, C, W, 1) → (B, C, 1, W)
        x_w = x_w.permute(0, 1, 3, 2)

        # Expand channels back and apply sigmoid
        a_h = self.conv_h(x_h).sigmoid()  # (B, C, H, 1)
        a_w = self.conv_w(x_w).sigmoid()  # (B, C, 1, W)

        # Apply attention
        out = identity * a_h * a_w
        return out


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def create_ca_block(channels: int, reduction: int = 16) -> CoordAtt:
    """Create a Coordinate Attention block.

    Args:
        channels: Number of input/output channels.
        reduction: Channel reduction ratio.

    Returns:
        CoordAtt module.
    """
    return CoordAtt(inp=channels, reduction=reduction)
