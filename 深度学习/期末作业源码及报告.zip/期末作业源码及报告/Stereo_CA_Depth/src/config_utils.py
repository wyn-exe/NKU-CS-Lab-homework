"""Shared config helpers for training and evaluation scripts."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Mapping

import yaml

from models import StereoBaseline


def load_yaml_config(config_path: str | Path) -> Dict[str, Any]:
    """Load a YAML experiment config."""
    path = Path(config_path)
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _legacy_attention_from_experiment(
    exp_name: str,
    model_cfg: Mapping[str, Any],
) -> Dict[str, Any]:
    """Map old CA boolean configs to the new attention config format."""
    default_ca_shallow = exp_name in {"ca_shallow", "ca_full"}
    default_ca_deep = exp_name in {"ca_deep", "ca_full"}

    use_ca_shallow = model_cfg.get("use_ca_shallow", default_ca_shallow)
    use_ca_deep = model_cfg.get("use_ca_deep", default_ca_deep)

    return {
        "shallow": {"type": "ca" if use_ca_shallow else "none"},
        "deep": {"type": "ca" if use_ca_deep else "none"},
    }


def get_attention_config(config: Mapping[str, Any]) -> Dict[str, Any]:
    """Return normalized shallow/deep attention config.

    Preferred format:

    model:
      attention:
        shallow: {type: none}
        deep: {type: ca, reduction: 16}

    Legacy ``use_ca_shallow`` and ``use_ca_deep`` keys are still supported.
    """
    exp_name = str(config.get("experiment_name", "baseline"))
    model_cfg = config.get("model", {})
    if "attention" not in model_cfg:
        return _legacy_attention_from_experiment(exp_name, model_cfg)

    attention = dict(model_cfg["attention"] or {})
    attention.setdefault("shallow", {"type": "none"})
    attention.setdefault("deep", {"type": "none"})
    return attention


def build_model_from_config(config: Mapping[str, Any]) -> StereoBaseline:
    """Create a model based on an experiment config."""
    model_cfg = config.get("model", {})
    attention = get_attention_config(config)
    deep_ch = model_cfg.get("deep_ch", model_cfg.get("channels", 64))
    cost_volume_cfg = dict(model_cfg.get("cost_volume", {}) or {})
    cost_volume_type = cost_volume_cfg.pop("type", "absdiff")
    cost_aggregation_cfg = dict(model_cfg.get("cost_aggregation", {}) or {})
    cost_aggregation_type = cost_aggregation_cfg.pop("type", "2d")
    refinement_cfg = dict(model_cfg.get("refinement", {}) or {})

    return StereoBaseline(
        max_disp=model_cfg.get("max_disp", 64),
        shallow_ch=model_cfg.get("shallow_ch", 32),
        deep_ch=deep_ch,
        shallow_attention=attention["shallow"],
        deep_attention=attention["deep"],
        agg_channels=model_cfg.get("agg_channels", 32),
        cost_volume_type=cost_volume_type,
        cost_volume_cfg=cost_volume_cfg,
        cost_aggregation_type=cost_aggregation_type,
        cost_aggregation_cfg=cost_aggregation_cfg,
        use_refinement=refinement_cfg.get("use", False),
        refinement_hidden_channels=refinement_cfg.get("hidden_channels", 32),
        refinement_num_blocks=refinement_cfg.get("num_blocks", 3),
    )
