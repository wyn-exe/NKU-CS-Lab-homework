"""Stereo disparity dataset classes.

Supports KITTI 2012/2015 and SceneFlow format, with synchronized
preprocessing and data augmentation.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

import cv2
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


def read_pfm(file_path: str) -> np.ndarray:
    """Read a PFM format disparity/flow file.

    PFM (Portable Float Map) is used by SceneFlow and Middlebury datasets
    to store floating-point disparity maps.

    Args:
        file_path: Path to the .pfm file.

    Returns:
        numpy array of shape (H, W) with float32 disparity values.
    """
    with open(file_path, "rb") as f:
        header = f.readline().decode("utf-8").strip()
        if header == "PF":
            color = True
        elif header == "Pf":
            color = False
        else:
            raise ValueError(f"Not a PFM file: {file_path}, header={header}")

        dims = f.readline().decode("utf-8").strip()
        width, height = map(int, dims.split())
        scale = float(f.readline().decode("utf-8").strip())
        endian = "<" if scale < 0 else ">"
        scale = abs(scale)

        data = np.fromfile(f, dtype=endian + "f")
        shape = (height, width, 3) if color else (height, width)
        data = data.reshape(shape)
        data = np.flipud(data)
        return data.copy()


def read_disparity(file_path: str) -> np.ndarray:
    """Read a disparity map from either PFM or PNG format.

    KITTI stores disparities as uint16 PNG where:
      actual_disparity = pixel_value / 256.0

    SceneFlow/Middlebury store disparities as float32 PFM.

    Args:
        file_path: Path to the disparity file (.pfm or .png).

    Returns:
        numpy array of shape (H, W) with float32 disparity values.
    """
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pfm":
        return read_pfm(file_path)
    elif ext == ".png":
        disp = cv2.imread(file_path, cv2.IMREAD_UNCHANGED)
        if disp is None:
            raise FileNotFoundError(f"Cannot read: {file_path}")
        if disp.dtype == np.uint16:
            return disp.astype(np.float32) / 256.0
        else:
            return disp.astype(np.float32)
    else:
        raise ValueError(f"Unsupported disparity format: {ext}")


class StereoDataset(Dataset):
    """Base stereo dataset for disparity estimation.

    Expected directory structure (KITTI-style):
        data_root/
        ├── image_2/   (left images, or image_0/)
        ├── image_3/   (right images, or image_1/)
        └── disp_occ_0/ (disparity maps, or disp_noc_0/)

    Expected directory structure (SceneFlow-style):
        data_root/
        ├── left/
        ├── right/
        └── disp/
    """

    def __init__(
        self,
        data_root: Union[str, Path],
        split: str = "train",
        left_dir: str = "image_2",
        right_dir: str = "image_3",
        disp_dir: str = "disp_occ_0",
        crop_size: Optional[Tuple[int, int]] = None,
        max_disp: int = 256,
        transform: Optional[Callable] = None,
    ) -> None:
        """Initialize stereo dataset.

        Args:
            data_root: Root directory containing image and disparity folders.
            split: 'train' or 'val'.
            left_dir: Folder name for left images.
            right_dir: Folder name for right images.
            disp_dir: Folder name for disparity maps.
            crop_size: (H, W) for random crop during training, or None.
            max_disp: Maximum valid disparity value.
            transform: Optional additional transforms.
        """
        self.data_root = Path(data_root)
        self.split = split
        self.crop_size = crop_size
        self.max_disp = max_disp
        self.transform = transform

        left_path = self.data_root / left_dir
        right_path = self.data_root / right_dir
        disp_path = self.data_root / disp_dir

        if not left_path.exists():
            raise FileNotFoundError(f"Left image directory not found: {left_path}")

        # Collect common image stems
        left_stems = {p.stem for p in left_path.glob("*") if p.suffix.lower() in {".png", ".jpg", ".jpeg"}}
        right_stems = {p.stem for p in right_path.glob("*") if p.suffix.lower() in {".png", ".jpg", ".jpeg"}}

        if disp_path.exists():
            disp_stems = {p.stem for p in disp_path.glob("*") if p.suffix.lower() in {".png", ".pfm"}}
        else:
            disp_stems = set()

        # Use intersection to ensure all three files exist
        if disp_stems:
            stems = sorted(left_stems & right_stems & disp_stems)
        else:
            stems = sorted(left_stems & right_stems)

        if len(stems) == 0:
            raise RuntimeError(
                f"No matching stereo pairs found in {self.data_root}.\n"
                f"  left ({left_dir}): {len(left_stems)} files\n"
                f"  right ({right_dir}): {len(right_stems)} files\n"
                f"  disp ({disp_dir}): {len(disp_stems)} files"
            )

        self.samples: List[Dict[str, Path]] = []
        for stem in stems:
            left_files = list(left_path.glob(f"{stem}.*"))
            right_files = list(right_path.glob(f"{stem}.*"))
            disp_files = list(disp_path.glob(f"{stem}.*")) if disp_stems else []

            if left_files and right_files:
                self.samples.append({
                    "stem": stem,
                    "left": left_files[0],
                    "right": right_files[0],
                    "disp": disp_files[0] if disp_files else None,
                })

        print(f"[{split}] Found {len(self.samples)} stereo pairs in {self.data_root}")

    def __len__(self) -> int:
        return len(self.samples)

    def _load_image(self, path: Path) -> np.ndarray:
        """Load image as RGB numpy array (H, W, 3)."""
        img = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(f"Cannot read image: {path}")
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def _synchronized_crop(
        self,
        left: np.ndarray,
        right: np.ndarray,
        disp: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Apply same random crop to left, right, and disparity.

        If disparity is scaled (e.g., at half resolution), it is cropped
        at the corresponding scale factor.

        Args:
            left: (H, W, 3) left image.
            right: (H, W, 3) right image.
            disp: (H_d, W_d) disparity map.

        Returns:
            Cropped (left, right, disp) tuple.
        """
        H_img, W_img = left.shape[:2]
        H_disp, W_disp = disp.shape[:2]
        crop_h, crop_w = self.crop_size

        if crop_h > H_img or crop_w > W_img:
            raise ValueError(
                f"Crop size ({crop_h}, {crop_w}) larger than image ({H_img}, {W_img})"
            )

        # Random top-left corner (image space)
        y0 = np.random.randint(0, H_img - crop_h + 1)
        x0 = np.random.randint(0, W_img - crop_w + 1)

        left = left[y0 : y0 + crop_h, x0 : x0 + crop_w]
        right = right[y0 : y0 + crop_h, x0 : x0 + crop_w]

        # Compute disparity-space crop coordinates
        scale_y = H_disp / H_img
        scale_x = W_disp / W_img
        dy0 = int(round(y0 * scale_y))
        dx0 = int(round(x0 * scale_x))
        dcrop_h = int(round(crop_h * scale_y))
        dcrop_w = int(round(crop_w * scale_x))

        disp = disp[dy0 : dy0 + dcrop_h, dx0 : dx0 + dcrop_w]
        return left, right, disp

    def _normalize(self, img: np.ndarray) -> np.ndarray:
        """Normalize image to [0, 1] float32."""
        return img.astype(np.float32) / 255.0

    def _build_valid_mask(self, disp: np.ndarray) -> np.ndarray:
        """Create boolean mask for valid disparity pixels.

        Valid if: 0 < disparity < max_disp
        """
        return (disp > 0) & (disp < self.max_disp)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """Get a single stereo sample.

        Returns:
            dict with keys:
                left: (3, H, W) tensor, right: (3, H, W) tensor,
                disp: (1, H, W) tensor, mask: (1, H, W) bool tensor,
                stem: str (filename stem)
        """
        sample = self.samples[idx]

        left = self._load_image(sample["left"])
        right = self._load_image(sample["right"])

        if sample["disp"] is not None:
            disp = read_disparity(str(sample["disp"]))
        else:
            # No ground truth (e.g., test set)
            H, W = left.shape[:2]
            disp = np.zeros((H, W), dtype=np.float32)

        # Synchronized random crop (training only)
        if self.split == "train" and self.crop_size is not None:
            left, right, disp = self._synchronized_crop(left, right, disp)

        # Normalize images
        left = self._normalize(left)
        right = self._normalize(right)

        # Build valid mask
        mask = self._build_valid_mask(disp)

        # Convert to tensors: (H, W, C) -> (C, H, W)
        left_t = torch.from_numpy(left).permute(2, 0, 1).float()
        right_t = torch.from_numpy(right).permute(2, 0, 1).float()
        disp_t = torch.from_numpy(disp).unsqueeze(0).float()
        mask_t = torch.from_numpy(mask).unsqueeze(0).bool()

        sample_dict = {
            "left": left_t,
            "right": right_t,
            "disp": disp_t,
            "mask": mask_t,
            "stem": sample["stem"],
        }

        if self.transform is not None:
            sample_dict = self.transform(sample_dict)

        return sample_dict
