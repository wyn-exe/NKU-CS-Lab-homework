"""Synchronized data augmentation transforms for stereo matching.

All transforms that modify geometry MUST be applied identically to both
left and right images, with corresponding scaling of disparity values.
"""

from __future__ import annotations

import random
from typing import Dict, Tuple

import numpy as np
import torch


def _hflip(x: torch.Tensor) -> torch.Tensor:
    """Flip a CHW tensor horizontally."""
    return torch.flip(x, dims=[-1])


def _adjust_brightness(x: torch.Tensor, factor: float) -> torch.Tensor:
    return torch.clamp(x * factor, 0.0, 1.0)


def _adjust_contrast(x: torch.Tensor, factor: float) -> torch.Tensor:
    mean = x.mean(dim=(-2, -1), keepdim=True)
    return torch.clamp((x - mean) * factor + mean, 0.0, 1.0)


def _adjust_saturation(x: torch.Tensor, factor: float) -> torch.Tensor:
    gray = (0.2989 * x[0:1] + 0.5870 * x[1:2] + 0.1140 * x[2:3])
    return torch.clamp((x - gray) * factor + gray, 0.0, 1.0)


class StereoRandomHorizontalFlip:
    """Randomly flip left-right pair horizontally.

    When flipping, left and right are swapped, and disparity values
    are negated (since the disparity direction reverses).
    This is a DIFFICULT transform to get right; use with caution.
    """

    def __init__(self, p: float = 0.0) -> None:
        # Disabled by default - can cause errors if not handled carefully
        self.p = p

    def __call__(self, sample: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        if random.random() < self.p:
            # Flip horizontally: swap left/right, negate disparity
            left = sample["left"]
            right = sample["right"]
            sample["left"] = _hflip(right)
            sample["right"] = _hflip(left)
            sample["disp"] = -_hflip(sample["disp"])
            sample["mask"] = _hflip(sample["mask"])
        return sample


class StereoColorJitter:
    """Apply color jitter to both images with the same parameters.

    Color jitter does not affect disparity geometry, so it is safe.
    """

    def __init__(
        self,
        brightness: float = 0.2,
        contrast: float = 0.2,
        saturation: float = 0.0,
        hue: float = 0.0,
        p: float = 0.5,
    ) -> None:
        self.brightness = brightness
        self.contrast = contrast
        self.saturation = saturation
        self.hue = hue
        self.p = p

    def __call__(self, sample: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        if random.random() < self.p:
            # Use same random parameters for both left and right
            # by applying the same transform
            left = sample["left"]
            right = sample["right"]

            # Generate consistent jitter parameters
            fn_idx = torch.randperm(4)
            b = None if self.brightness == 0 else random.uniform(
                max(0, 1 - self.brightness), 1 + self.brightness
            )
            c = None if self.contrast == 0 else random.uniform(
                max(0, 1 - self.contrast), 1 + self.contrast
            )
            s = None if self.saturation == 0 else random.uniform(
                max(0, 1 - self.saturation), 1 + self.saturation
            )
            h = None if self.hue == 0 else random.uniform(-self.hue, self.hue)

            for fn_id in fn_idx:
                if fn_id == 0 and b is not None:
                    left = _adjust_brightness(left, b)
                    right = _adjust_brightness(right, b)
                elif fn_id == 1 and c is not None:
                    left = _adjust_contrast(left, c)
                    right = _adjust_contrast(right, c)
                elif fn_id == 2 and s is not None:
                    left = _adjust_saturation(left, s)
                    right = _adjust_saturation(right, s)
                elif fn_id == 3 and h is not None:
                    # Hue jitter is intentionally not implemented in the
                    # pure-PyTorch path; keep it disabled for stereo safety.
                    pass

            sample["left"] = left
            sample["right"] = right
        return sample


class StereoGaussianNoise:
    """Add independent Gaussian noise to both images."""

    def __init__(self, std: float = 0.02, p: float = 0.3) -> None:
        self.std = std
        self.p = p

    def __call__(self, sample: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        if random.random() < self.p:
            for key in ["left", "right"]:
                noise = torch.randn_like(sample[key]) * self.std
                sample[key] = torch.clamp(sample[key] + noise, 0.0, 1.0)
        return sample


class ToTensor:
    """Ensure images are tensors (pass-through if already tensors)."""

    def __call__(self, sample: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        return sample


def build_train_transform(
    brightness: float = 0.2,
    contrast: float = 0.2,
    noise_std: float = 0.02,
) -> object:
    """Build training augmentation pipeline.

    Returns a callable that applies a sequence of safe transforms.
    Safe = does not break epipolar geometry.
    """
    transforms = [
        StereoColorJitter(brightness=brightness, contrast=contrast, p=0.5),
        StereoGaussianNoise(std=noise_std, p=0.3),
    ]
    return Compose(transforms)


class Compose:
    """Compose multiple transforms sequentially."""

    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, sample):
        for t in self.transforms:
            sample = t(sample)
        return sample
