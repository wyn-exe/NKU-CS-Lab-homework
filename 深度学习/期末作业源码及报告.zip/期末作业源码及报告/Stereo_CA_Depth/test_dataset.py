"""Verify the stereo dataset pipeline correctness.

Checks:
1. Data loading (left, right, disparity, mask)
2. Synchronized cropping
3. Shape and value ranges
4. Data augmentation transforms
5. Visualizes a sample for manual inspection
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from datasets import StereoDataset, build_train_transform, read_disparity


def test_dataset_loading() -> None:
    """Test basic dataset loading."""
    print("=" * 60)
    print("Test 1: Dataset Loading")
    print("=" * 60)

    ds = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=(256, 512),
        max_disp=64,
    )

    assert len(ds) == 300, f"Expected 300 samples, got {len(ds)}"
    print(f"[PASS] Dataset loaded: {len(ds)} samples")

    # Get first sample
    sample = ds[0]
    for key in ["left", "right", "disp", "mask", "stem"]:
        assert key in sample, f"Missing key: {key}"
    print(f"[PASS] Sample keys: {list(sample.keys())}")

    # Check shapes
    assert sample["left"].shape == (3, 256, 512), f"Left shape: {sample['left'].shape}"
    assert sample["right"].shape == (3, 256, 512), f"Right shape: {sample['right'].shape}"
    assert sample["disp"].shape == (1, 256, 512), f"Disp shape: {sample['disp'].shape}"
    assert sample["mask"].shape == (1, 256, 512), f"Mask shape: {sample['mask'].shape}"
    print(f"[PASS] Shapes correct: left={sample['left'].shape}, disp={sample['disp'].shape}")

    # Check value ranges
    assert 0.0 <= sample["left"].max() <= 1.0, f"Left max: {sample['left'].max()}"
    assert 0.0 <= sample["right"].max() <= 1.0, f"Right max: {sample['right'].max()}"
    print(f"[PASS] Image values in [0, 1]: left∈[{sample['left'].min():.2f},{sample['left'].max():.2f}], "
          f"right∈[{sample['right'].min():.2f},{sample['right'].max():.2f}]")

    # Check disparity
    valid_mask = sample["mask"].squeeze().numpy()
    valid_disp = sample["disp"].squeeze().numpy()[valid_mask]
    if len(valid_disp) > 0:
        print(f"[PASS] Valid disparity: min={valid_disp.min():.1f}, max={valid_disp.max():.1f}, "
              f"mean={valid_disp.mean():.1f}, valid_pixels={len(valid_disp)}")
    print()


def test_synchronized_crop() -> None:
    """Test that left/right/disparity crops are synchronized."""
    print("=" * 60)
    print("Test 2: Synchronized Crop")
    print("=" * 60)

    import cv2

    # Load without crop first
    ds = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=None,  # No crop
        max_disp=64,
    )

    # Load full image, then manually verify a specific crop region
    for seed in range(5):
        np.random.seed(seed)
        torch.manual_seed(seed)

        ds_crop = StereoDataset(
            data_root="data/SyntheticStereo/train",
            split="train",
            left_dir="left",
            right_dir="right",
            disp_dir="disp",
            crop_size=(128, 256),
            max_disp=64,
        )

        full = ds[seed]
        cropped = ds_crop[seed]

        # Check cropped image is smaller
        assert cropped["left"].shape[1] == 128, f"Crop H: {cropped['left'].shape}"
        assert cropped["left"].shape[2] == 256, f"Crop W: {cropped['left'].shape}"
        print(f"[PASS] Seed {seed}: Crop shape correct ({cropped['left'].shape[1]}x{cropped['left'].shape[2]})")

        # Verify the disparity has valid values in the cropped region
        valid_crop = cropped["mask"].squeeze().numpy()
        if valid_crop.sum() > 0:
            print(f"  Valid pixels in crop: {valid_crop.sum()} / {valid_crop.size}")
    print()


def test_dataloader() -> None:
    """Test DataLoader integration."""
    print("=" * 60)
    print("Test 3: DataLoader Integration")
    print("=" * 60)

    ds = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=(256, 512),
        max_disp=64,
    )

    loader = DataLoader(ds, batch_size=4, shuffle=True, num_workers=0)

    batch = next(iter(loader))
    print(f"[PASS] Batch left:  {batch['left'].shape}")
    print(f"[PASS] Batch right: {batch['right'].shape}")
    print(f"[PASS] Batch disp:  {batch['disp'].shape}")
    print(f"[PASS] Batch mask:  {batch['mask'].shape}")
    print(f"[PASS] Batch stems: {batch['stem']}")

    assert batch["left"].shape == (4, 3, 256, 512)
    assert batch["disp"].shape == (4, 1, 256, 512)
    print()


def test_disparity_read() -> None:
    """Test disparity reading in KITTI uint16 format."""
    print("=" * 60)
    print("Test 4: Disparity Reading")
    print("=" * 60)

    # Read first disparity file
    disp_files = sorted(Path("data/SyntheticStereo/train/disp").glob("*.png"))
    assert len(disp_files) > 0, "No disparity files found"

    # Read directly
    disp = read_disparity(str(disp_files[0]))
    print(f"[PASS] Disparity shape: {disp.shape}")
    print(f"[PASS] Disparity dtype: {disp.dtype}")
    print(f"[PASS] Disparity range: [{disp.min():.1f}, {disp.max():.1f}]")

    # The synthetic data uses uint16 * 256 format
    import cv2
    raw = cv2.imread(str(disp_files[0]), cv2.IMREAD_UNCHANGED)
    if raw.dtype == np.uint16:
        expected = raw.astype(np.float32) / 256.0
        assert np.allclose(disp, expected, atol=1e-3), "Disparity reading mismatch"
        print(f"[PASS] KITTI uint16 format correctly decoded")
    print()


def test_transforms() -> None:
    """Test augmentation transforms don't break data."""
    print("=" * 60)
    print("Test 5: Data Augmentation Transforms")
    print("=" * 60)

    ds = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=(256, 512),
        max_disp=64,
    )

    transform = build_train_transform(brightness=0.3, contrast=0.3, noise_std=0.03)

    sample = ds[0]
    original_left = sample["left"].clone()
    original_disp = sample["disp"].clone()

    transformed = transform(sample)
    assert "left" in transformed and "right" in transformed
    assert transformed["disp"] is not None
    assert transformed["mask"] is not None

    print(f"[PASS] Transform preserves all keys")

    # Color jitter may change pixel values
    l1_diff = (transformed["left"] - original_left).abs().mean().item()
    print(f"[PASS] Left image L1 diff after transform: {l1_diff:.6f}")

    # Disparity and mask should be unchanged by color/noise transforms
    disp_diff = (transformed["disp"] - original_disp).abs().max().item()
    print(f"[PASS] Disparity unchanged by transform: max_diff={disp_diff:.6f}")
    print()


def test_validation_mode() -> None:
    """Test validation mode (no random crop)."""
    print("=" * 60)
    print("Test 6: Validation Mode")
    print("=" * 60)

    ds_val = StereoDataset(
        data_root="data/SyntheticStereo/val",
        split="val",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=None,  # Full image for validation
        max_disp=64,
    )

    assert len(ds_val) == 30, f"Expected 30 val samples, got {len(ds_val)}"
    sample = ds_val[0]
    print(f"[PASS] Val dataset: {len(ds_val)} samples")
    print(f"[PASS] Val sample shape: left={sample['left'].shape}, disp={sample['disp'].shape}")
    print()


def test_edge_cases() -> None:
    """Test edge cases and error handling."""
    print("=" * 60)
    print("Test 7: Edge Cases")
    print("=" * 60)

    # Test with different directory names
    ds2 = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        max_disp=64,
    )
    assert len(ds2) == 300
    print("[PASS] Works with default params (no crop)")

    # Test max_disp filtering
    ds3 = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        max_disp=20,  # Lower than actual max (64)
    )
    sample = ds3[0]
    mask = sample["mask"].squeeze().numpy()
    disp = sample["disp"].squeeze().numpy()
    if mask.sum() > 0:
        assert (disp[mask] < 20).all(), f"Max disp exceeds limit: {disp[mask].max()}"
    print(f"[PASS] max_disp=20 filtering works: {mask.sum()} valid pixels of {mask.size}")

    # Test FileNotFoundError
    try:
        StereoDataset(data_root="nonexistent/path", split="train")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        print("[PASS] Correctly raises FileNotFoundError for invalid path")
    print()


def visualize_sample() -> None:
    """Create a visualization of a sample for manual inspection."""
    print("=" * 60)
    print("Creating visualization...")
    print("=" * 60)

    ds = StereoDataset(
        data_root="data/SyntheticStereo/train",
        split="train",
        left_dir="left",
        right_dir="right",
        disp_dir="disp",
        crop_size=(256, 512),
        max_disp=64,
    )

    sample = ds[0]

    fig, axes = plt.subplots(1, 4, figsize=(16, 4))
    axes[0].imshow(sample["left"].permute(1, 2, 0).numpy())
    axes[0].set_title("Left Image")
    axes[0].axis("off")

    axes[1].imshow(sample["right"].permute(1, 2, 0).numpy())
    axes[1].set_title("Right Image")
    axes[1].axis("off")

    disp = sample["disp"].squeeze().numpy()
    mask = sample["mask"].squeeze().numpy()
    disp_vis = np.where(mask, disp, np.nan)
    im = axes[2].imshow(disp_vis, cmap="turbo")
    axes[2].set_title("Disparity (GT)")
    axes[2].axis("off")
    plt.colorbar(im, ax=axes[2], fraction=0.046, pad=0.04)

    # Error map visualization (all zero for GT, just show mask)
    axes[3].imshow(~mask, cmap="gray")
    axes[3].set_title("Invalid Pixels (black=valid)")
    axes[3].axis("off")

    output_dir = Path("results/visualizations")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "sample_verification.png"
    plt.tight_layout()
    plt.savefig(output_path, dpi=100, bbox_inches="tight")
    plt.close()
    print(f"[PASS] Visualization saved to: {output_path}")
    print()


if __name__ == "__main__":
    test_dataset_loading()
    test_synchronized_crop()
    test_dataloader()
    test_disparity_read()
    test_transforms()
    test_validation_mode()
    test_edge_cases()
    visualize_sample()

    print("=" * 60)
    print("ALL TESTS PASSED [PASS]")
    print("=" * 60)
