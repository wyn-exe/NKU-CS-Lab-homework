# Stereo_CA_Depth

轻量双目深度估计课程项目。项目目标是在一个可控的轻量 stereo baseline 上，按统一接口接入不同注意力或改进模块，并通过训练、评估、消融和可视化证明模块是否带来收益。

Gitee 仓库：

```text
https://gitee.com/song-cancan/Stereo_CA_Depth.git
```

## 项目结构

```text
Stereo_CA_Depth/
├── configs/                    # 实验配置，训练/评估统一从这里读取
│   ├── baseline.yaml
│   ├── baseline_3d.yaml
│   ├── acv_lite.yaml
│   ├── acv_lite_3d.yaml
│   ├── acv_lite_ca_shallow.yaml
│   ├── acv_lite_ca_shallow_3d.yaml
│   ├── ca_shallow.yaml
│   ├── ca_deep.yaml
│   ├── ca_full.yaml
│   ├── se_full.yaml
│   ├── eca_full.yaml
│   ├── kitti2012_baseline.yaml
│   ├── baseline_refinement.yaml
│   ├── acv_lite_refinement.yaml
│   └── acv_lite_3d_refinement.yaml
├── data/                       # 本地数据和数据准备脚本，大数据不提交
│   ├── download_data.py
│   └── README.md
├── docs/                       # 实验记录、消融记录、结果分析、报告草稿
├── experiments/                # 训练输出，checkpoint/log/config，默认忽略
├── members/                    # 成员贡献说明
├── report/                     # 最终报告材料
├── src/
│   ├── config_utils.py         # 统一 YAML 解析和模型构建
│   ├── train.py                # 训练入口
│   ├── evaluate.py             # 指标评估入口
│   ├── datasets/               # 双目数据读取、PFM/PNG disparity 解析、增强
│   ├── losses/                 # 视差损失
│   ├── metrics/                # EPE/D1/MAE/RMSE/参数量
│   └── models/
│       ├── acv_lite.py          # ACV-lite cost volume
│       ├── attention_modules.py # 模块注册表：CA/SE/ECA/none
│       ├── ca_module.py         # Coordinate Attention 实现
│       ├── feature_extractor.py # 共享权重 CNN，提供 shallow/deep 插槽
│       ├── cost_volume.py       # cost volume + 2D/lightweight 3D aggregation
│       ├── refinement.py        # StereoNet-style edge-aware refinement
│       └── stereo_baseline.py   # 完整 stereo 网络
└── test_dataset.py             # 数据 pipeline 检查
```

## Baseline 框架

输入为左图、右图和 ground truth disparity：

```text
left/right image: B x 3 x H x W
gt disparity:     B x 1 x H x W
```

模型流程：

```text
left image / right image
→ shared CNN feature extractor
→ optional attention at shallow feature (H/2)
→ optional attention at deep feature (H/4)
→ cost volume (absdiff or acv_lite)
→ cost aggregation (2D or light3d)
→ softmax disparity regression
→ bilinear upsampling to full resolution
→ optional edge-aware refinement
→ predicted disparity
```

默认 baseline 设置：

- 浅层通道：32
- 深层通道：64
- 特征分辨率：H/4
- `max_disp=64` 时，低分辨率候选视差数为 `64 / 4 = 16`
- 聚合器：逐 disparity slice 的轻量 2D CNN
- 损失：valid mask 区域 Smooth L1
- 指标：EPE、D1-error、MAE、RMSE

这个 baseline 的优点是轻量、易跑、插入模块清晰；缺点是 cost aggregation 没有显式跨视差维度建模，精度上限不高。报告中应客观描述它是课程实验 baseline，不是 SOTA stereo 网络。

## 模块管理

### 注意力模块

模块注册入口在：

```text
src/models/attention_modules.py
```

当前支持：

| type     | 模块                          | 说明                             |
| -------- | ----------------------------- | -------------------------------- |
| `none` | `nn.Identity`               | baseline，不加注意力             |
| `ca`   | `CoordAtt`                  | Coordinate Attention，主改进模块 |
| `se`   | `SqueezeExcitation`         | SE channel attention，对比模块   |
| `eca`  | `EfficientChannelAttention` | ECA channel attention，对比模块  |

注意力模块有两个插槽：

```text
model.attention.shallow  # H/2，低级纹理和边缘特征
model.attention.deep     # H/4，高级匹配特征
```

配置示例：

```yaml
model:
  shallow_ch: 32
  deep_ch: 64
  max_disp: 64
  agg_channels: 32
  attention:
    shallow:
      type: ca
      reduction: 16
    deep:
      type: ca
      reduction: 16
```

`src/config_utils.py` 负责把 YAML 转换为模型。旧配置中的 `use_ca_shallow/use_ca_deep` 仍兼容，但新实验应统一使用 `model.attention`。

### Cost volume 模块

Cost volume 模块目前支持：

| type         | 模块                  | 文件               | 说明                                                                                       |
| ------------ | --------------------- | ------------------ | ------------------------------------------------------------------------------------------ |
| `absdiff`  | `AbsDiffCostVolume` | `cost_volume.py` | baseline，逐候选视差计算左右特征绝对差                                                     |
| `acv_lite` | `ACVLiteCostVolume` | `acv_lite.py`    | ACVNet 思想的轻量化版本，在 abs-diff volume 后拼接 group-wise correlation attention priors |

配置示例：

```yaml
model:
  cost_volume:
    type: acv_lite
    temperature: 0.07
    groups: 8
    gate_init: 0.1
```

ACV-lite 与完整 ACVNet 不同：这里没有复现完整网络，而是把“由左右特征相关性生成视差注意力”的思想压缩为一个轻量 cost volume 模块，便于和当前教学 baseline 对接。当前实现使用 group-wise correlation priors，并加入 learnable gate 控制 prior 强度，使模型训练初期更接近 baseline，随后逐步学习是否使用 ACV-lite 信号。

Cost aggregation 模块目前支持：

| type        | 模块                      | 文件               | 说明                                                   |
| ----------- | ------------------------- | ------------------ | ------------------------------------------------------ |
| `2d`      | `CostAggregator2D`      | `cost_volume.py` | baseline，逐 disparity slice 独立做 2D CNN             |
| `light3d` | `CostAggregator3DLight` | `cost_volume.py` | 改进 baseline，使用轻量 3D CNN 显式混合 disparity 维度 |

配置示例：

```yaml
model:
  cost_aggregation:
    type: light3d
    hidden_channels: 24
```

### Refinement 模块

Refinement 模块目前支持：

| type           | 模块                    | 文件              | 说明                                     |
| -------------- | ----------------------- | ----------------- | ---------------------------------------- |
| `none`       | 不使用 refinement       | -                 | 默认，直接输出双线性上采样结果           |
| `refinement` | `EdgeAwareRefinement` | `refinement.py` | StereoNet-style 轻量边缘感知残差细化模块 |

配置示例：

```yaml
model:
  refinement:
    use: true
    hidden_channels: 16
    num_blocks: 2
```

## 新增模块指南

当前已经注册化管理的是 **feature extractor 里的 shallow/deep 注意力模块**。新增模块是否需要在 `src/models/` 下新建 `.py` 文件，取决于模块复杂度：

| 情况                                                            | 推荐做法                                                                                                   |
| --------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| 很小的注意力模块，例如 SE/ECA/轻量 CA 变体                      | 直接写在 `src/models/attention_modules.py`                                                               |
| 代码较长、包含多个类、需要单独测试或后续复用                    | 在 `src/models/` 下新建独立文件，例如 `cbam_module.py`，再在 `attention_modules.py` 中 import 并注册 |
| 非注意力模块，例如 refinement、cost aggregation、3D cost volume | 建议新建独立 `.py` 文件，并在对应构建入口中增加配置开关；当前 `ATTENTION_REGISTRY` 不负责管理这些模块  |

也就是说，新增注意力模块的最小改动可以只发生在 `attention_modules.py` 和 YAML 配置里；但复杂模块不要都塞进同一个文件。

以新增一个小型注意力模块 `my_attn` 为例：

1. 在 `src/models/attention_modules.py` 中新增模块类。

```python
class MyAttention(nn.Module):
    def __init__(self, channels: int, ratio: int = 4) -> None:
        super().__init__()
        ...

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        ...
        return x
```

2. 新增 builder。

```python
def _my_attn_builder(channels: int, ratio: int = 4, **kwargs: Any) -> nn.Module:
    return MyAttention(channels, ratio=ratio)
```

3. 注册到 `ATTENTION_REGISTRY`。

```python
ATTENTION_REGISTRY = {
    ...
    "my_attn": _my_attn_builder,
}
```

4. 新建配置文件，例如 `configs/my_attn_full.yaml`。

```yaml
experiment_name: my_attn_full
model:
  shallow_ch: 32
  deep_ch: 64
  max_disp: 64
  agg_channels: 32
  attention:
    shallow:
      type: my_attn
      ratio: 4
    deep:
      type: my_attn
      ratio: 4
```

5. 训练、评估、记录结果。

```bash
python src/train.py --config configs/my_attn_full.yaml
python src/evaluate.py --config configs/my_attn_full.yaml --checkpoint experiments/my_attn_full/checkpoint_best.pt
```

新增模块时不要直接在 `train.py` 里写 if/else；训练脚本只负责训练，模块选择必须放在配置和注册表里。

如果采用独立文件，例如 `src/models/cbam_module.py`，推荐流程是：

```python
# src/models/cbam_module.py
class CBAM(nn.Module):
    ...
```

然后在 `attention_modules.py` 中导入并注册：

```python
from .cbam_module import CBAM

def _cbam_builder(channels: int, reduction: int = 16, **kwargs: Any) -> nn.Module:
    return CBAM(channels, reduction=reduction)

ATTENTION_REGISTRY = {
    ...
    "cbam": _cbam_builder,
}
```

配置文件中继续只写模块名：

```yaml
attention:
  shallow:
    type: cbam
  deep:
    type: cbam
```

## 数据准备

合成数据用于快速验证 pipeline：

```bash
python data/download_data.py --mode generate --target data/SyntheticStereo --num-samples 300
python data/download_data.py --mode verify --target data/SyntheticStereo --max-disp 64
```

KITTI2012 用于真实数据实验：

```bash
python data/download_data.py --mode download --year 2012 --target data/KITTI2012 --val-count 20
python data/download_data.py --mode verify --target data/KITTI2012 --max-disp 256
```

如果已经手动下载 KITTI：

```bash
python data/download_data.py --mode prepare --source path/to/training --target data/KITTI2012 --val-count 20
python data/download_data.py --mode verify --target data/KITTI2012 --max-disp 256
```

## 训练

训练的命令格式为：

```
python src/train.py --config configs/你的模型配置文件（yaml格式）
```

先跑 baseline：

```bash
python src/train.py --config configs/baseline.yaml
python src/train.py --config configs/baseline_3d.yaml
```

CA 主实验：

```bash
python src/train.py --config configs/ca_full.yaml
```

CA 插入位置消融：

```bash
python src/train.py --config configs/ca_shallow.yaml
python src/train.py --config configs/ca_deep.yaml
python src/train.py --config configs/ca_full.yaml
```

其他模块对比：

```bash
python src/train.py --config configs/acv_lite.yaml
python src/train.py --config configs/acv_lite_3d.yaml
python src/train.py --config configs/acv_lite_ca_shallow.yaml
python src/train.py --config configs/acv_lite_ca_shallow_3d.yaml
python src/train.py --config configs/se_full.yaml
python src/train.py --config configs/eca_full.yaml
```

KITTI2012 baseline：

```bash
python src/train.py --config configs/kitti2012_baseline.yaml
```

训练输出默认保存到配置里的 `training.save_dir`，例如：

```text
experiments/baseline/
├── checkpoint_latest.pt
├── checkpoint_best.pt
├── checkpoint_epoch_005.pt
├── config.yaml
└── logs/
```

## 测试和评估

评估验证集指标（base）：

```bash
python src/evaluate.py --config configs/baseline.yaml --checkpoint experiments/baseline/checkpoint_best.pt
```

保存指标 JSON：

```bash
格式为：python src/evaluate.py --config configs/你的模型配置yaml文件 --checkpoint experiments/存放你模型训练权重的文件夹/checkpoint_best.pt --output results/模型名.json
例如：
python src/evaluate.py --config configs/ca_full.yaml --checkpoint experiments/ca_full/checkpoint_best.pt --output results/ca_full_metrics.json
```

评估脚本会输出：

```text
EPE / D1 / MAE / RMSE / LOSS / Params / num_samples
```

如果没有传 `--checkpoint`，脚本会评估随机初始化权重，只能用于 smoke test，不能写进报告。

## 测试对比表

当前结果来自 SyntheticStereo 验证集，共 30 对图像。各模型使用对应配置训练 20 epoch，并用 `checkpoint_best.pt` 评估。指标越低越好。

主对比：

| Model                  | Attention                       |    EPE |     D1 |    MAE |   RMSE |  Params | 结论                            |
| ---------------------- | ------------------------------- | -----: | -----: | -----: | -----: | ------: | ------------------------------- |
| baseline               | none                            | 3.2129 | 0.2182 | 3.2129 | 6.3087 | 150,464 | 基准                            |
| baseline_3d            | light3d aggregation             | 3.2027 | 0.2491 | 3.2027 | 5.9571 | 145,464 | RMSE 改善，D1 变差              |
| ca_full                | CA shallow+deep                 | 3.3499 | 0.2299 | 3.3499 | 6.5296 | 152,800 | 相比 baseline 变差              |
| acv_lite               | ACV-lite cost volume            | 3.1269 | 0.2150 | 3.1269 | 6.4011 | 152,769 | EPE/D1 改善，RMSE 略差          |
| acv_lite_3d            | ACV-lite + light3d              | 3.1165 | 0.2377 | 3.1165 | 5.9982 | 145,657 | EPE 最好，RMSE 改善，D1 变差    |
| acv_lite_ca_shallow_3d | ACV-lite + shallow CA + light3d | 3.1190 | 0.2388 | 3.1190 | 6.0068 | 146,441 | EPE 接近 acv_lite_3d，D1 变差   |
| baseline_refinement    | none + refinement               | 3.0842 | 0.2300 | 3.0842 | 5.8351 | 160,561 | EPE/RMSE 改善，D1 略差          |
| acv_lite_refinement    | ACV-lite + refinement           | 3.0722 | 0.2216 | 3.0722 | 6.0595 | 162,866 | EPE/D1 表现良好，综合指标优秀   |
| acv_lite_3d_refinement | ACV-lite + light3d + refinement | 2.9387 | 0.2160 | 2.9387 | 5.9541 | 155,754 | EPE 最优，D1 接近最优，综合最佳 |

消融：

| Model                  | shallow | deep |    EPE |     D1 |    MAE |   RMSE | 结论                             |
| ---------------------- | ------- | ---- | -----: | -----: | -----: | -----: | -------------------------------- |
| baseline               | none    | none | 3.2129 | 0.2182 | 3.2129 | 6.3087 | 基准                             |
| baseline_3d            | none    | none | 3.2027 | 0.2491 | 3.2027 | 5.9571 | RMSE 改善，D1 变差               |
| ca_shallow             | CA      | none | 3.1477 | 0.2197 | 3.1477 | 6.2031 | EPE/RMSE 小幅改善，D1 略差       |
| ca_deep                | none    | CA   | 3.2452 | 0.2306 | 3.2452 | 6.2473 | EPE/D1 变差，RMSE 略好           |
| ca_full                | CA      | CA   | 3.3499 | 0.2299 | 3.3499 | 6.5296 | 整体变差                         |
| acv_lite               | none    | none | 3.1269 | 0.2150 | 3.1269 | 6.4011 | EPE/D1 改善，RMSE 略差           |
| acv_lite_3d            | none    | none | 3.1165 | 0.2377 | 3.1165 | 5.9982 | EPE 最好，RMSE 改善，D1 变差     |
| acv_lite_ca_shallow    | CA      | none | 3.2138 | 0.2385 | 3.2138 | 6.1853 | RMSE 最好，但 D1 明显变差        |
| acv_lite_ca_shallow_3d | CA      | none | 3.1190 | 0.2388 | 3.1190 | 6.0068 | EPE 接近 acv_lite_3d，但 D1 仍差 |
| baseline_refinement    | none    | none | 3.0842 | 0.2300 | 3.0842 | 5.8351 | EPE/RMSE 改善，D1 略差           |
| acv_lite_refinement    | none    | none | 3.0722 | 0.2216 | 3.0722 | 6.0595 | EPE/D1 表现良好，综合指标优秀    |
| acv_lite_3d_refinement | none    | none | 2.9387 | 0.2160 | 2.9387 | 5.9541 | EPE 最优，D1 接近最优，综合最佳  |
|                        |         |      |        |        |        |        |                                  |

当前结论：CA 对插入位置敏感。浅层 CA 能带来约 2.0% 的 EPE 改善和约 1.7% 的 RMSE 改善，但 D1 没有改善；深层 CA 和 shallow+deep 组合没有提升。ACV-lite 是当前最稳定的单模块改进，EPE 和 D1 都优于 baseline。light3d 能改善 RMSE，但会让 D1 变差。ACV-lite + shallow CA + light3d 的三组合没有优于 ACV-lite + light3d，说明浅层 CA 与当前 ACV-lite/light3d 组合存在收益重叠或训练不稳定。Refinement 能有效提升 EPE 和 RMSE。**ACV-lite + light3d + Refinement 是当前综合最佳方案**，EPE 最低，D1 接近最优，整体优于 baseline。

## 常见问题

`experiments/` 为空：

说明当前文件夹没有训练产物。先运行训练命令，或向已有训练者索取对应 checkpoint。

CA 配置和 baseline 不公平：

新配置已统一学习率、batch size、num_workers。正式实验中除模块类型外，其余超参应保持一致。
