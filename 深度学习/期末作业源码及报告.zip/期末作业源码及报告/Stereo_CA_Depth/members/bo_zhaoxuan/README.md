# Bo Zhaoxuan 个人贡献说明

## 负责内容

- 实现 StereoNet-style edge-aware refinement 模块，包括残差块设计和边缘感知视差细化网络。
- 完成 refinement 模块与现有 stereo baseline 的集成，在 bilinear 上采样后进行残差细化。
- 设计并实现 refinement 模块的配置接口，支持 hidden_channels 和 num_blocks 参数调整。
- 创建多个配置文件：`baseline_refinement.yaml`、`acv_lite_refinement.yaml`、`acv_lite_3d_refinement.yaml`。
- 完成 SyntheticStereo 上 refinement 相关实验的完整训练验证：
  - Baseline + Refinement：验证 refinement 模块的有效性
  - ACV-lite + Refinement：验证与 ACV-lite 的组合效果
  - ACV-lite + light3d + Refinement：最终最佳组合方案验证
- 系统评估各实验方案，量化指标对比（EPE、D1-error、RMSE 等）。
- 维护和更新项目文档：
  - 更新 README.md 的模块管理、项目结构、训练/评估说明
  - 更新 `docs/实验记录.md` 完整实验数据和结论
  - 更新 `docs/消融实验记录.md` 完整消融分析
  - 更新 `docs/结果分析.md` 最终最佳方案推荐

## 提交记录

| 次数 | Commit | 内容 | 状态 |
|---:|---|---|---|
| 1 | 已提交 | 实现 StereoNet-style refinement 模块和配置接口 | 已完成 |
| 2 | 已提交 | 创建 refinement 配置文件，更新 config_utils.py 支持 | 已完成 |
| 3 | 已提交 | 完成 baseline_refinement、acv_lite_refinement 实验训练与评估 | 已完成 |
| 4 | 已提交 | 完成 acv_lite_3d_refinement 最终最佳方案训练验证 | 已完成 |
| 5 | 已提交 | 更新项目文档（README.md、实验记录、消融实验、结果分析） | 已完成 |

## 最近验证结果

### Baseline + Refinement 完整训练

配置：`configs/baseline_refinement.yaml`

- 数据集：SyntheticStereo
- 模型：Baseline + StereoNet-style refinement
- 训练轮数：20 epoch
- 参数量：160,561
- 最佳验证 EPE：3.0842 (Baseline: 3.2129)
- 最佳验证 RMSE：5.8351 (Baseline: 6.3087)
- 保存目录：`experiments/baseline_refinement`

训练现象：
- 模型能够稳定收敛。
- 验证 EPE 逐步下降，最终比纯 Baseline 提升约 4%。
- refinement 模块能够有效学习残差，保持边缘清晰。

### ACV-lite + Refinement 完整训练

配置：`configs/acv_lite_refinement.yaml`

- 数据集：SyntheticStereo
- 模型：ACV-lite cost volume + StereoNet-style refinement
- 训练轮数：20 epoch
- 参数量：162,866
- 最佳验证 EPE：3.0722
- 最佳验证 D1-error：0.2216
- 保存目录：`experiments/acv_lite_refinement`

### 最终最佳方案：ACV-lite + light3d + Refinement

配置：`configs/acv_lite_3d_refinement.yaml`

- 数据集：SyntheticStereo
- 模型：ACV-lite cost volume + light3d aggregation + StereoNet-style refinement
- 训练轮数：20 epoch
- 参数量：155,754
- 最佳验证指标：
  - **EPE: 2.9387** (所有方案中最低)
  - **D1-error: 0.2160** (接近 pure Baseline 的 0.2182)
  - **RMSE: 5.9541**
- 保存目录：`experiments/acv_lite_3d_refinement`

结论：
- 三个模块完美组合，在 EPE、D1-error、RMSE 上全面超越纯 Baseline！
- EPE 从 3.21 降到 2.94，提升约 8.5%！
- D1-error 保持在 0.216，几乎没有损失边缘对齐质量。
- RMSE 也有明显改善，说明对大误差的抑制效果良好。

## 说明

本目录用于满足课程要求中的成员子目录和个人提交记录说明。项目代码统一维护在仓库公共目录中，避免不同成员重复复制同一套工程文件。
