# Song Cancan 个人贡献说明

## 负责内容

- 项目结构初始化与 Gitee 仓库规划。
- 实验规划文档、数据说明文档和成员贡献记录维护。
- 轻量级 stereo baseline 设计与实现，包括特征提取、cost volume、cost aggregation 和 disparity regression。
- Coordinate Attention 模块实现，以及 CA-shallow、CA-deep、CA-full 三种插入位置配置。
- Smooth L1 损失函数、EPE/D1/MAE/RMSE 指标实现。
- SyntheticStereo 合成数据生成、数据读取 pipeline 验证和可视化检查。
- KITTI 2012 真实 stereo 数据接入、整理、校验和训练配置补充。
- 修复 baseline 中的训练增强接入、配置读取和无效视差代价 padding 问题。
- 完成 SyntheticStereo baseline 完整训练验证，并使用 best checkpoint 对 KITTI 真实左右图进行推理可视化。

## 提交记录

| 次数 | Commit | 内容 | 状态 |
|---:|---|---|---|
| 1 | `352f125` | 初始化项目结构、README、配置文件、文档模板和基础代码入口 | 已完成 |
| 2 | `ef0bf0f` | 添加数据读取与同步预处理流程 | 已完成 |
| 3 | `76df2ae` | 实现轻量级 stereo baseline | 已完成 |
| 4 | `927fa4a` | 记录架构瓶颈诊断，整理成员贡献记录 | 已完成 |
| 5 | `43b84ba` | 添加项目上下文说明文件 | 已完成 |
| 6 | `1c62328` | 接入 KITTI 2012 真实 stereo 数据下载、整理和校验流程 | 已完成 |
| 7 | `37e303a` | 忽略生成的 results 实验输出目录 | 已完成 |
| 8 | 待提交 | 修复 baseline 训练增强、配置读取和 cost volume 无效 padding；完成短训与完整 baseline 验证 | 已完成 |

## 最近验证结果

### SyntheticStereo baseline 完整训练

配置：`configs/baseline.yaml`

- 数据集：SyntheticStereo
- 模型：baseline，不加入 Coordinate Attention
- 训练轮数：20 epoch
- 参数量：150,464
- 最佳验证 EPE：3.2804
- 保存目录：`experiments/baseline`

训练现象：

- 模型能够稳定收敛。
- 验证 EPE 从 epoch 0 的 4.470 降至最佳 3.280。
- 后期 EPE 在 3.2 到 3.5 附近波动，说明当前 H/4 cost volume、D=16、无 refinement 的干净 baseline 存在合理精度上限。

### KITTI 真实图推理验证

使用 SyntheticStereo 上训练得到的 baseline best checkpoint，对 KITTI 2012 验证集真实左右图进行跨域推理。

- 样本：`000002_10`
- 可视化：左图、右图、GT disparity、预测 disparity、伪深度图和误差图。
- 有效像素 EPE：8.67（仅统计 GT disparity 小于 64 的区域）

结论：

- 模型能够预测出粗略远近结构，不是随机噪声。
- 由于模型只在合成数据上训练，且 baseline 结构较轻，迁移到真实 KITTI 图像时存在明显 domain gap。
- 当前模型适合作为教学用轻量级 baseline 和后续 CA 消融实验参照，不作为高精度 KITTI 模型。

## 说明

本目录用于满足课程要求中的成员子目录和个人提交记录说明。项目代码统一维护在仓库公共目录中，避免不同成员重复复制同一套工程文件。
