# Wang Yinuo 个人贡献说明

## 负责内容

- 整理并优化项目整体实验框架，使训练、评估、配置和模块管理流程更加清晰。
- 规范模块新增和使用方式：
  - 将注意力模块统一纳入 `ATTENTION_REGISTRY` 管理。
  - 将模型构建逻辑整理到 `src/config_utils.py`。
  - 通过 YAML 配置控制 attention、cost volume、cost aggregation 和 refinement 等模块。
- 重写和完善项目 `README.md`，补充项目结构、模块添加指南、训练方式、测试方式和实验结果表。
- 加入 ACV-lite cost volume 模块：
  - 实现 group-wise correlation attention prior。
  - 加入 learnable gate 控制 ACV-lite prior 强度。
  - 创建 `acv_lite.yaml`、`acv_lite_ca_shallow.yaml` 等配置。
- 加入 light3d aggregation 模块：
  - 实现轻量 3D cost aggregation。
  - 通过 `cost_aggregation.type: light3d` 支持跨 disparity 维度建模。
  - 创建 `baseline_3d.yaml` 和 `acv_lite_3d.yaml` 配置。
- 完成 SyntheticStereo 上 ACV-lite、light3d 及其组合方案的消融实验：
  - Baseline vs ACV-lite
  - Baseline vs light3d aggregation
  - ACV-lite + shallow CA
  - ACV-lite + light3d aggregation
- 维护实验记录文档，整理 EPE、D1-error、MAE、RMSE、Loss 和参数量等指标。
- 根据实验结果分析模块收益和局限，明确 ACV-lite 是当前较稳定的模块级改进，light3d 与组合方案存在 D1-error 权衡。

## 提交记录

| 次数 | Commit | 内容 | 状态 |
|---:|---|---|---|
| 1 | 已提交 | 整理项目框架，规范模块配置和模型构建流程 | 已完成 |
| 2 | 已提交 | 新增 attention 模块注册机制和统一配置接口 | 已完成 |
| 3 | 已提交 | 实现 ACV-lite cost volume 模块及相关配置 | 已完成 |
| 4 | 已提交 | 实现 light3d aggregation 模块及组合配置 | 已完成 |
| 5 | 已提交 | 完成 ACV-lite、light3d 和组合方案消融实验，更新实验记录与 README | 已完成 |

## 最近验证结果

### ACV-lite 完整训练

配置：`configs/acv_lite.yaml`

- 数据集：SyntheticStereo
- 模型：ACV-lite cost volume，不加入 CA
- 训练轮数：20 epoch
- 参数量：152,769
- 最佳验证 EPE：3.1269
- 最佳验证 D1-error：0.2150
- 最佳验证 RMSE：6.4011
- 保存目录：`experiments/acv_lite`

实验现象：

- 相比 baseline，ACV-lite 将 EPE 从 3.2129 降至 3.1269。
- D1-error 从 0.2182 降至 0.2150，是当前较稳定的模块级改进。
- RMSE 略高于 baseline，说明 ACV-lite 对平均误差和坏点率有帮助，但对大误差抑制仍有限。

### Baseline + light3d aggregation 完整训练

配置：`configs/baseline_3d.yaml`

- 数据集：SyntheticStereo
- 模型：Baseline + lightweight 3D aggregation
- 训练轮数：20 epoch
- 参数量：145,464
- 最佳验证 EPE：3.2027
- 最佳验证 D1-error：0.2491
- 最佳验证 RMSE：5.9571
- 保存目录：`experiments/baseline_3d`

实验现象：

- light3d aggregation 能明显降低 RMSE，说明跨 disparity 聚合有助于减少部分大误差。
- D1-error 明显变差，说明该模块也会带来坏点率上升的问题。
- 该实验适合作为 cost aggregation 消融与权衡分析。

### ACV-lite + light3d aggregation 组合实验

配置：`configs/acv_lite_3d.yaml`

- 数据集：SyntheticStereo
- 模型：ACV-lite cost volume + lightweight 3D aggregation
- 训练轮数：20 epoch
- 参数量：145,657
- 最佳验证 EPE：3.1165
- 最佳验证 D1-error：0.2377
- 最佳验证 RMSE：5.9982
- 保存目录：`experiments/acv_lite_3d`

实验现象：

- 该组合获得比 baseline 更低的 EPE 和 RMSE。
- D1-error 高于 baseline 和单独 ACV-lite，说明组合模块在坏点率上仍不稳定。
- 该结果说明 ACV-lite 与跨 disparity aggregation 可以互补，但需要进一步优化坏点控制。

## 说明

本目录用于满足课程要求中的成员子目录和个人提交记录说明。项目代码统一维护在仓库公共目录中，避免不同成员重复复制同一套工程文件。
